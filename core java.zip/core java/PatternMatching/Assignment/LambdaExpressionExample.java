interface Lambda{  
    public void draw();  
}  
public class LambdaExpressionExample {  
    public static void main(String[] args) {  
        int width=10;  
  
        
        Lambda l=()->{  
            System.out.println("Drawing "+width); 
        };  
        l.draw();  
    }  
}