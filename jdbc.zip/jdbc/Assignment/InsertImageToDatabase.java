import java.sql.*;
import java.io.*;
class InsertImageToDatabase
{
 public static void main(String args[])
 {
	 try
	 {
		 Class.forName("com.mysql.jdbc.Driver");
		 String url="jdbc:mysql://localhost:3306/image";
		String user="root";
		String pass="root";
		
		Connection con=DriverManager.getConnection(url,user,pass);
		PreparedStatement p=con.prepareStatement("insert into image values(?,?)");
		p.setString(1,"101");
		
		FileInputStream fin=new FileInputStream("d:\\yash\\image1.PNG");
		p.setBinaryStream(2,fin,fin.available());
		p.executeUpdate();
		System.out.println("undate");
		con.close();
		
		
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	 
	 
 } 
	
}