import React,{Component} from 'react';



class Home extends React.Component



{



    render()



    {



        return(<div>



            <h1>welcome to Home page</h1>

           



        </div>);



    }



}



export default Home;