class ThreadInterrupred extends Thread
{
public void run()
{
//System.out.println(Thread.currentThread().getName()+""+Thread.interrupted());
//System.out.println(Thread.currentThread());
//System.out.println(Thread.currentThread());
//System.out.println(Thread.currentThread().getName()+""+Thread.currentThread().interrupted());
//System.out.println(Thread.currentThread().isInterrupted());

try
{
for(int i=1;i<=4;i++)
{
System.out.println(i);
Thread.sleep(2000);

}
}
catch(Exception e)
{
e.printStackTrace();
}
}
public static void main(String args[])
{
ThreadInterrupred ti=new ThreadInterrupred();
ti.start();
ti.setName("the thread");
ti.interrupted();

}
}