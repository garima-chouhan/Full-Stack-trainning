abstract class Language
{
 abstract void display();
  
}

class Java extends Language
{
void display()
{
System.out.println("java");
}

}
class Php extends Language
{
  void display()
{
System.out.println("php");
}
public static void main(String args[])
{
Java j=new Java();
j.display();


}

} 