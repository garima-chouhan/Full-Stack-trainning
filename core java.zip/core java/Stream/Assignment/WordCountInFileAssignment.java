import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class WordCountInFileAssignment 
{   
	public static void main(String[] args) throws IOException 
	{
		
		
		BufferedReader br = null;
		
		
		
		int charCount = 0;
		
		int wordCount = 0;
		
		int lineCount = 0;
		
		
		
		
		try
		{
			
			
			 br = new BufferedReader(new FileReader("d:/yash/yash.txt"));
			
			String Line = br.readLine();
			
			while (Line != null)
			{

				lineCount++;
				
				String[] words = Line.split(" ");
				
				wordCount = wordCount + words.length;
		
				for (String word : words)
				{
					
					
					charCount = charCount + word.length();
				}
				
				
				
				Line = br.readLine();
			}
			
			
			
			System.out.println("Number Of Chars In A File : "+charCount);
			
			System.out.println("Number Of Words In A File : "+wordCount);
			
			System.out.println("Number Of Lines In A File : "+lineCount);
			
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
				br.close();           
		
		}
	}	
}