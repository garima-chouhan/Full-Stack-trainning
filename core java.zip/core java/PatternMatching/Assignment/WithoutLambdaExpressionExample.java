interface Lambda{  
    public void draw();  
}  
public class WithoutLambdaExpressionExample {  
    public static void main(String[] args) {  
        int width=10;  
  
        //without lambda, Drawable implementation using anonymous class  
        Lambda l=new Lambda(){  
            public void draw(){System.out.println("Drawing "+width);}  
        };  
        l.draw();  
    }  
}