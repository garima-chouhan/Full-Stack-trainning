class MethodOverLoading1
{
 void display(int a, int b)
{
System.out.println("1");
}

void display(int a)
{
System.out.println("2");
}
public static void main(String args[])
{
MethodOverLoading1 m1=new MethodOverLoading1();
m1.display(20, 10);

}
}