class MethodOverLoading3
{
 void display(int a)
{
System.out.println("1");
}

void display(String a)
{
System.out.println("2");
}
public static void main(String args[])
{
MethodOverLoading3 m1=new MethodOverLoading3();
m1.display( "hi");

}
}