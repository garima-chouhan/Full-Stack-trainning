class Outer
{
class Inner
{
  void show()
  {
  
  System.out.println("Non-static class");
  }

}

}
public class NonStaticOuterInner
{
public static void main(String args[])
{
Outer o=new Outer();
Outer.Inner io=o.new Inner();
io.show();


}

}