import java.util.regex.Pattern;

public class PatternCompileExample {

    public static void main(String[] args) {

        String text    =
                "This is the text to be searched " +
                "for occurrences of the http:// pattern.";

        String patternString = ".*http:// pattern.*";

         Pattern pattern = Pattern.compile(patternString);
    }
}