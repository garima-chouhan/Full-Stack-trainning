class Person
{
String name,dateofbirth;

Person(String name,String dateofbirth)
{
 this.name=name;
 this.dateofbirth=dateofbirth;
}

}

class Teacher extends Person
{
double salary;
 String subject;

Teacher(String name,String dateofbirth,double salary,String subject)
{
super(name,dateofbirth);
this.salary=salary;
this.subject=subject;
}
void display()
{
System.out.println();
}
}
class Student extends Person
{
 int studentId;
Student(String name,String dateofbirth,int studentId)
{
super(name,dateofbirth);
this.studentId=studentId;

}

}

class CollegeStudends extends Student
{
String collegeName;
String year;
void CollegeStudents(String name,String dateofbirth,int studentId,String year,String collegeName)
{
super(name,dateofbirth,studentId);
this.year=year;
this.collegeName=collegeName;

}

void display()
{
System.out.println();
}
}

public class Information
{
public Static void main(String args[])
{
Teacher t=new Teacher("JAYNAM","31/10/1991","JAVA",40000);
CollegeStudents c=new CollegeStudents("Garima","31/10/1998",101,"last year","patel college");
 c.display();
}

}
