import java.sql.*;
class FirstJdbcDemo
{

public static void main(String args[])
{
 try
 {
 Class.forName("com.mysql.jdbc.Driver");
 
 String url="jdbc:mysql://localhost:3306/yash";
 String user="root";
 String password="root";
 Connection con=DriverManager.getConnection(url,user,password);
 
 if(con!=null)
 {
 System.out.println("connection is create sucessfully");
 }
 else
 {
 System.out.println("connection is not created");
 }
 con.close();
 }

catch(Exception e)
{
	e.printStackTrace();
	
}

}
}