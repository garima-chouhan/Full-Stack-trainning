class MethodOverLoading2
{
 void display(int a, String b)
{
System.out.println("1");
}

void display(String a,int b)
{
System.out.println("2");
}
public static void main(String args[])
{
MethodOverLoading2 m1=new MethodOverLoading2();
m1.display(20, "hi");

}
}