class EqualsMethodExample{
  public static void main(String args[])
{
String s="Hello ";
String s1="HELLO";

 if(s.equals(s1)){

System.out.println("Strings are equal");

}
else{

System.out.println("Strings are not equal");

}

}


}