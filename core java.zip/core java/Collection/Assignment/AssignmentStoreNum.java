import java.util.ArrayList;
import java.util.*;
class StoreNum{
private long num;
private double num1;
StoreNum(int n,double d){
num=n;
num1=d;
}
public String toString() {
return +num +"\n"+ num1;
}
}
public class AssignmentStoreNum {
     public static void main(String args[]) {
    ArrayList<StoreNum> al=new ArrayList<StoreNum>();
    al.add(new StoreNum(2,4.5));
    al.add(new StoreNum(7,8.0));
    al.add(new StoreNum(8923,0.07));
    for(StoreNum element:al)
  System.out.println(element + "\n");

     }
}