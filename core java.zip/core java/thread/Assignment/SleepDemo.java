public class SleepDemo
{
public static void main(String args[])
{
  try
  {
  for(int i=1; i<=4; i++)
  {
  //Thread.sleep(-1);//illegalArgumentException..value is negative//inturrp
  Thread.sleep(2000);
  System.out.println(i);
  }
  }
  catch(Exception e)
  {
 System.out.println(e);
  }
  
  

}
}