clas Test
{
 void show(int a)
{
System.out.println("1");

}

}

class MethodOverRidding1 extends Test
{
 void show(int a)
{
System.out.println("2");
}
public static void main(String args[])
{
 MethodOverRidding1 m=new  MethodOverRidding1();
 m.show(20);
}

}