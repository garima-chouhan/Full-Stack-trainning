import java.io.InputStreamReader;
import java.io.BufferedReader;
class Buffered{ 
        String Str; char ch[];
        void display()
		{
		 System.out.println("Hello");  	
			
		}   
    public static void main(String args[]) throws Exception
	{
		
        InputStreamReader i=new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(i);
         System.out.println("Enter name");
            String name=br.readLine();
            System.out.println(name);
			
		Buffered b=new Buffered();
         b.display();		
              
    }
}