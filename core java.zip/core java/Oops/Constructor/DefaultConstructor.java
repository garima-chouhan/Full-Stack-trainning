class DefaultConstructor
{
 int a;
 String s;
  boolean b;

public static void main(String args[])
{
 
  DefaultConstructor d=new DefaultConstructor();

 System.out.println("Default value is:");
  System.out.println("a=" +d.a);
 System.out.println("s=" +d.s);
 System.out.println("b=" +d.b);
}

}