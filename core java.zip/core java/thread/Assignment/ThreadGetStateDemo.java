public class ThreadGetStateDemo implements Runnable {

   public void run() {

      
      Thread.State s = Thread.currentThread().getState();
      System.out.println(Thread.currentThread().getName());
      System.out.println("state = " + s);
   }

   public static void main(String args[]) {
      Thread t = new Thread(new ThreadGetStateDemo());
      t.start();   
   }
} 