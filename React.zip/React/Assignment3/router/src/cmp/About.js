import React,{Component} from 'react';



class About extends React.Component



{



    render()



    {



        return(<div>



            <h1> welcome to About page</h1>

           



        </div>);



    }



}



export default About;