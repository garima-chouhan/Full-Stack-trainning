class EncapsulationEmployee
{
 private int empid;
 public void SetEmpId(int empid)
{
 this.empid=empid;
}
public int getEmpId()
{
 return empid;
}
}
 class Employee
{
 public static void main(String args[])
 {
 EncapsulationEmployee e=new EncapsulationEmployee();
 e.SetEmpid(1000);
System.out.println(e.getEmpId());

}

}