class Employee
{
 String Name;
 int emp_id;

public Employee(String Name, int emp_id)
{

this.Name=Name;
this.emp_id=emp_id;



}
public static void main(String args[])
{
Employee e1=new Employee("yash",101);
e1.emp_id=101;
e1.Name="Garima";


}


}