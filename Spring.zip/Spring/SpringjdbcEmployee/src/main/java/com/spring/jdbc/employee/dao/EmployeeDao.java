package com.spring.jdbc.employee.dao;

import com.spring.jdbc.employee.entities.Employee;

public class EmployeeDao {
	public int insert(Employee emp);
	public int updatedetails(Employee emp);
	public int delete(int empid);
	public Employee getEmployee(int empid);


}
