import javax.swing.JButton;  
import javax.swing.JFrame;
import javax.swing.JTextField; 
import java.awt.event.ActionListener; 
import java.awt.event.ActionEvent;
public class SwingExample {  
public static void main(String[] args) {  
    JFrame f=new JFrame("Button");
     JFrame f=f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JButton b=new JButton("Click Here");
    final JTextField tf=new JTextField();	
    b.setBounds(50,100,95,30);
    b.addActionListener(new ActionListener(){  
public void actionPerformed(ActionEvent e){  
            tf.setText("Welcome to Javatpoint.");  
        }  
    });  	
    f.add(b);
    f.add(tf);	
    f.setSize(400,400);  
    f.setLayout(null);  
    f.setVisible(true);
    	
}  
}  