enum Days {
   MONDAY,TUESDAY,WENSDAY,THRUSDAY,FRIDAY
}
public class EnumMain {
   public static void main(String args[]){
      Days d;
      d = Days.TUESDAY;
      switch(d) {
         case MONDAY:
            System.out.println("You choose MONDAY");
            break;
         case TUESDAY:
            System.out.println("You choose TUESDAY");
            break;
         case WENSDAY:
            System.out.println("You choose WENSDAY");
            break;
         case THRUSDAY:
            System.out.println("You choose THRUSDAY");
            break;
         case FRIDAY:
            System.out.println("You choose FRIDAY");
            break;
         default:
            System.out.println("you choose to SATURDAY AND SUNDAY");
            break;
      }
   }
}