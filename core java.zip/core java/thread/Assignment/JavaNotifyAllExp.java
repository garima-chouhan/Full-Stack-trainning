class NotifyAll1 extends Thread   
{  
    public void run()  
    {  
        synchronized(this)  
        {  
            System.out.println("Starting of " + Thread.currentThread().getName());  
            try {  
                this.wait();  
            }  
            catch (InterruptedException e) {  
                e.printStackTrace();}  
            System.out.println(Thread.currentThread().getName() + "...notified");  
        }  
    }  
}  
class NotifyAll2 extends Thread {  
    NotifyAll1 notifyAll1;  
    NotifyAll2(NotifyAll1 notifyAll1)  
    {  
        this.notifyAll1 = notifyAll1;  
    }  
    public void run()  
    {  
        synchronized(this.notifyAll1)  
        {  
            System.out.println("Starting of " + Thread.currentThread().getName());  
            try {  
                this.notifyAll1.wait();  
            }  
            catch (InterruptedException e) {  
                e.printStackTrace();  
            }  
            System.out.println(Thread.currentThread().getName() + "...notified");  
        }  
    }  
}   
class NotifyAll3 extends Thread   
{  
    NotifyAll1 notifyAll1;  
    NotifyAll3(NotifyAll1 notifyAll1)  
    {  
        this.notifyAll1 = notifyAll1;  
    }  
    public void run()  
    {  
        synchronized(this.notifyAll1)  
        {  
            System.out.println("Starting of " + Thread.currentThread().getName());  
             
            this.notifyAll1.notifyAll();  
            System.out.println(Thread.currentThread().getName() + "...notified");  
        }  
    }  
}  
public class JavaNotifyAllExp   
{  
    public static void main(String[] args) throws InterruptedException  
    {  
        NotifyAll1 notifyAll1 = new NotifyAll1();  
        NotifyAll2 notifyAll2 = new NotifyAll2(notifyAll1);  
        NotifyAll3 notifyAll3 = new NotifyAll3(notifyAll1);  
          
        // creating the threads   
        Thread t1 = new Thread(notifyAll1, "Thread-1");  
        Thread t2 = new Thread(notifyAll2, "Thread-2");  
        Thread t3 = new Thread(notifyAll3, "Thread-3");  
          
        // call run() method  
        t1.start();  
        t2.start();  
        Thread.sleep(100);  
        t3.start();  
    }  
}  