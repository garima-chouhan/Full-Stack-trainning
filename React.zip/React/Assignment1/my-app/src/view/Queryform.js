import React, {Component} from 'react';

class Queryform extends React.Component

{

render()

{

    return(

        <div>

            <h3>QueryForm</h3>
            <fieldset>

                <form class="form">
                <label>First name:</label>
                 <input type="text" name="fname" size="15"/>
                 <label>Last name:</label>
                 <input type="text" name="lname" size="15"/>
                 <br></br>
                 <input class="submit" type="button" value="submit"/>
                </form>
            </fieldset>
            

        </div>

    );

}



}

export default Queryform;