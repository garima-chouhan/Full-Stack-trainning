import java.util.Scanner;
class FirstAndLast
{

public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       System.out.println("Enter the string");
        String string = input.nextLine();
        int x = string.length();
        System.out.println(string.substring(1,x-1)); 
       
    }
}