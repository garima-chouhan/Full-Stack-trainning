class Thread1 extends Thread
{
    public void run()
	{
	   System.out.println("I am thread1");
	   }
	}
class Thread2 extends Thread
{
    public void run()
	{
	   System.out.println("I am thread2");
	   }
	}
class Thread3 extends Thread
{
    public void run()
	{
	   System.out.println("I am thread3");
	   }
	}
class Thread4 extends Thread
{
    public void run()
	{
	   System.out.println("I am thread4");
	   }
	}
public class MultiThreadMulti{
      public static void main(String[] args){
	  Thread1 t1=new Thread1();
	  t1.start();
	  Thread2 t2=new Thread2();
	  t2.start();
	  Thread3 t3=new Thread3();
	  t3.start();
	  Thread4 t4=new Thread4();
	  t4.start();
	  }
}