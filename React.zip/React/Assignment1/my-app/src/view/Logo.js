import React, {Component} from 'react';

class Logo extends React.Component

{

render()

{

    return(

        <div>

            <h3>Logo</h3>
            <img class="logo1" src="logo1.png"></img>

        </div>

    );

}



}

export default Logo;