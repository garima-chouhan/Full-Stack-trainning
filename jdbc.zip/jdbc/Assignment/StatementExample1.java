import java.sql.*;
import java.util.*;
class StatementExample1{
public static void main(String args[])throws Exception{
Class.forName("com.mysql.jdbc.Driver");
System.out.println("Driver loaded");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp_record","root","root");
System.out.println("Connection Established"); 
Statement stmt=con.createStatement();  
  

int result=stmt.executeUpdate("delete from emp_record where eno=101");  
System.out.println(result+" records affected");  
con.close();  
}}  