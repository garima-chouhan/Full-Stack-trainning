import React,{Component} from 'react';

class Bigimage extends React.Component

{

    render()

    {

        return(<div>

           
             <img class="image2" src="office.jpg"></img>
        </div>);

    }

}

export default Bigimage;