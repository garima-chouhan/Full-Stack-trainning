import java.io.*;
import java.util.*;
 

enum fruits {
    
    Apple(120),
    Kiwi(60),
    Banana(20),
    Orange(80);
 
    
    private int price;
 
    
    fruits(int pr) 
	{
	price = pr; 
	}
 
    
    int totalPrice() 
	{ 
	return price;
	}
}
 

class FruitEnum {
 
    
    public static void main(String[] args)
    {
       
        System.out.println("Total price of fruits : ");
 
        
        for (fruits f : fruits.values())
 
            
            System.out.println(f + " costs "
                               + f.totalPrice()
                               + " rupees per kg.");
    }
}
