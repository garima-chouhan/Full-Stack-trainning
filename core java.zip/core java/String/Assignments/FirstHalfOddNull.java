import java.util.Scanner;
class FirstHalfOddNull
{

public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       System.out.println("Enter the string");
        String string = input.nextLine();
        int x = string.length();
        System.out.println(string.substring(0, x/2)); 
       
    }
}