class SubStringExample{
   public static void main(String args[])
{
String s="welcome ";
System.out.println(3,7);


}

}