class SingleThreadSingle extends Thread{
public void run()
{
System.out.println("i am Single thread");
}
public static void main(String args[])
{
 ThreadDemo t=new ThreadDemo();
 t.start();

}


}