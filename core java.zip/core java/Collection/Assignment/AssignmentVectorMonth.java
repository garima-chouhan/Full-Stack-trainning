import java.util.Vector;
import java.util.Iterator;
class AssignmentVectorMonth {

public static void main(String[] args)
{

Vector<String> s = new Vector<>();


s.add("JANUARY");
s.add("FEB");
s.add("MARCH");
s.add("APRIL");
s.add("MAY");
s.add("JUNE");
s.add("JULY");
s.add("AGU");
s.add("SEP");
s.add("OCT");
s.add("NOV");
s.add("DEC");
String E=s.get(3);
System.out.println("Element of index 3 is:"+E);

Iterator i=s.iterator();

while(i.hasNext())
{
	System.out.println(i.next());
}


}
}