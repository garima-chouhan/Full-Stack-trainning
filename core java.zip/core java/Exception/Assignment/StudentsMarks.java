import java.util.Scanner;

 class StudentsMarks extends RuntimeException {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < 2; i++) 
		{
			String name = "";
			int SubA;
			int SubB;
			int SubC;
			
			try {				
				name = sc.nextLine();
				
				if (sc.hasNextInt())
					SubA = sc.nextInt();
				else
				{
					throw new NumberFormatException();
				}
				if (sc.hasNextInt())
					SubB = sc.nextInt();
				else
				{
					throw new NumberFormatException();
			    }
				if (sc.hasNextInt())
					SubC = sc.nextInt();
				else
				{
					throw new NumberFormatException();
				}
				if (SubA < 0) 
				{
					throw new StudentsMarks();
				}
				if (SubA > 100)
				{
					throw new StudentsMarks();
				}
				
				if (SubB < 0)
				{
					throw new StudentsMarks();
				}
				if (SubB > 100)
				{
					throw new StudentsMarks();
				}
				
				if (SubC < 0) 
				{
					throw new StudentsMarks();
				}
				if (SubC > 100)
				{
					throw new StudentsMarks();
				}
				
				
			}
			catch (ArithmeticException e) {
				System.out.println(e.getMessage());
			} 
			catch (StudentsMarks e) {
				System.out.println(e.getMessage());
			}
			catch (StudentsMarks e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("Name: " + name);
			System.out.println("Marks of subject A: " + SubA);
			System.out.println("Marks of subject B: " + SubB);
			System.out.println("Marks of subject C: " + SubC);
		}
		
		sc.close();

	}

}