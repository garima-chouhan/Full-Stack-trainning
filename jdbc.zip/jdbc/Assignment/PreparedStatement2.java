import java.sql.*;
import java.util.IOException;
class PreparedStatement2
{
  public static void main(String args[]) throws IOException
   {
      try
	  {
	    Class.forName("con.mysql.jdbc.Driver");
		
		String url="jdbc:mysql://localhost:3306/emp_record";
		String user="root";
		String pass="root";
		
		Connection con=DriverManager.getConnection(url,user,pass);
		
		String s="insert into employee_record(eno,ename,esal,eddr) values(?,?,?,?)";
		PreparedStatement p=con.prepareStatement(s);
		
		p.setInt(1,2400);
		p.setString(2,"chouhan");
		p.setInt(3,4567);
		p.setString(4,"surana nagar");
		p.executeUpdate();
		
		System.out.println("inserted successfully");
		con.close();
	
	  }
	  catch(Exception e)
	  {
	    e.printStackTrace();
	  }
   }

}