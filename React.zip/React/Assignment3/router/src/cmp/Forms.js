import React,{Component} from 'react';



class Forms extends React.Component



{



    render()



    {



        return(<div>



            <h1>welcome to Forms page</h1>

           



        </div>);



    }



}



export default Forms;