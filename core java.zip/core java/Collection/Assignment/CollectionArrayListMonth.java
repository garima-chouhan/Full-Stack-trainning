import java.util.ArrayList;
import java.util.Iterator;
class CollectionArrayListMonth {

public static void main(String[] args)
{

ArrayList<String> s = new ArrayList<String>();


s.add("JANUARY");
s.add("FEB");
s.add("MARCH");
s.add("APRIL");
s.add("MAY");
s.add("JUNE");
s.add("JULY");
s.add("AGU");
s.add("SEP");
s.add("OCT");
s.add("NOV");
s.add("DEC");
System.out.println(s);

Iterator i=s.iterator();

while(i.hasNext())
{
	System.out.println(i.next());
}

for(String j:s)
{
	
System.out.println("months of the year"+" " + j);	
}
}
}