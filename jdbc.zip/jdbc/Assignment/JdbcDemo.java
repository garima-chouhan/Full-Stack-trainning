import java.sql.*;
class JdbcDemo
{
public static void main(String[] args)
{
try
{
//load the driver
Class.forName("com.mysql.jdbc.Driver");
//create connection
String url="jdbc:mysql://localhost:3306/garima";
String user="root";
String pass="root";
Connection con=DriverManager.getConnection(url,user,pass);
if(con!=null)
{
System.out.println("Connection is created Successfully");
}
else
{
System.out.println("Connection is created Successfully");
} //step 3 : create the query
String q="select * from employee";
Statement st=con.createStatement();
ResultSet set=st.executeQuery(q);
//step 4: process the data
while(set.next())
{
int id=set.getInt("empID"); //(1)
String name=set.getString("empName");
System.out.println("id:" + id);
System.out.println("empName:" +name);
}
con.close();
}
catch(Exception e)
{
e.printStackTrace();
}
}
}