class ParameterizedConstructor
{
 int age;
 String Name;
 
 
private void details(String N, int a)
{
 Name=N;
 age=a;

}

void display()
{
System.out.println("name of "+Name+  "age of"+age);
}

public static void main(String args[])
{
 
ParameterizedConstructor p=new ParameterizedConstructor();

 p.details("Garima",10);
 p.display();

}

}