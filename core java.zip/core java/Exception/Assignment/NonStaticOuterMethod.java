public class NonStaticOuterMethod {

    public class InnerClass 
	{
       void show()
	   {
         int x = 5;

	   }
    }

    public InnerClass createInner() {
        return new InnerClass();
    }
}

public class Main {

    public static void main(String[] args) {
       Outer.Inner oi=new Outer.Inner();
	   oi.show();
    }
}