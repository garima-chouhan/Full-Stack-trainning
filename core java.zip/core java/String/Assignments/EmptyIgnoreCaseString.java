class EmptyIgnoreCaseString{
  public static void main(String args[])
{
 String s1="GARIMA";
 String s2="Garima";
if(s1.equalsIgnoreCase(s2)){

 System.out.println("Both are string");
}
else{
System.out.println("Both are string");
}
}

}