 public class Box
{
 double w,h,d;
 
 Box(double w, double h,double d)
{
this.w=w;
this.h=h;
this.d=d;

}
 Double volume()
{
 double v;
v=w*h*d;
return v;

}

public static void main(String args[])
{
 Box b = new Box();
 System.out.println(b.volume());
}
}