 class Outer
{
	
 static class Inner
{
  void show()
  {
  
  System.out.println("static class");
  }
}
}



public class StaticOuterInner
{
public static void main(String args[])
{

Outer.Inner io=new Outer.Inner();
io.show();


}

}