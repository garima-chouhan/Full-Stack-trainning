package com.spring.jdbc.employee.entities;

public class Employee {
	private String empname;
	private int empid;
	private int contactno;
	private int salary;
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		empname = empname;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public Employee(String empname, int empid, int contactno, int salary) {
		super();
		empname = empname;
		this.empid = empid;
		this.contactno = contactno;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [Empname=" + empname + ", empid=" + empid + ", contactno=" + contactno + ", salary=" + salary
				+ "]";
	}
	
	
	

}
