class FirSecMaxMinArray
{
 public static void main(String args[])
{
  int[] a={0,2,8,6,1,9};
  
 int max1=max2=0;
 
 for(int i=0;i<a.length;i++)
{
  if(a[i] > max1)
  max2=max1;
 max1 =a[i];
}
if (max2<a[i] && a[i]<max1)
{
 max2=a[i];

}

  



System.out.println("First Maximum value is:" +max1);
System.out.println("First Minimum value is:" +min1);
//System.out.println("Second Maximum value is:" +max2);
//System.out.println("Second Minimum value is:" +min2);
}
}