class Demo1
{
 int i;

void value(int i)
{
 this.i=i;


}

void show()
{
 System.out.println(i);

}  
}

class Demo1Main
{
 public static void main(String args[])
{
 Demo1 d= new Demo1();
 d.value(20);
 d.show();
}


}