import java.io.Serializable;

 class Employee implements Serializable {
	private String name;
	private String department;
	private String designation;
	private double salary;
	
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getDepartment() 
	{
		return department;
	}
	public void setDepartment(String department)
	{
		this.department = department;
	}
	public String getDesignation()
	{
		return designation;
	}
	public void setDesignation(String designation) 
	{
		this.designation = designation;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	class Employee1
	{    	
		public static void main(String args[])
		{
		     Employee e = new Employee();
			 System.out.println(e);
			File f=new File("d:/yash/yash.txt");
            
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            oos.writeObject(e);
            oos.flush();
            oos.close();
        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

	
	  