class Demo6 
 {
    String name;
    int age;
   public Demo6 SetValues()
{
      
      this.name = name;
      this.age = age;
      return this;
   }
   public void display()
 {
      System.out.println("name: "+name);
      System.out.println("age: "+age);
   }
   public static void main(String args[]) {
      Demo6 obj = new Demo6();
       obj.SetValues();
      obj.display();
   }
}