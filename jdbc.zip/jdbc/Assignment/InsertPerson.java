import java.sql.*;
import java.util.*;
class InsertPerson{
public static void main(String args[])throws Exception{
Class.forName("com.mysql.jdbc.Driver");
System.out.println("Driver loaded");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/persons","root","root");
System.out.println("insert"); 
Statement stmt=con.createStatement();  
  

int result=stmt.executeUpdate("insert from persons(101,10,101)");  
System.out.println(result+" records affected");  
con.close();  
}} 