import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class PropertiesAssignment2 {

	public static void main(String[] args) {
		Properties p = new Properties();
		Set<Entry<Object, Object>> set = p.entrySet();
		
		
		p.setProperty("West Bengal", "Kolkata");
		p.setProperty("India", "Delhi");
		p.setProperty("Bihar", "Patna");

		Iterator<Entry<Object, Object>> t = set.iterator();
		
		while (t.hasNext()) {
			Entry<Object, Object> m = t.next();
			System.out.println(m);
		}
	}

}