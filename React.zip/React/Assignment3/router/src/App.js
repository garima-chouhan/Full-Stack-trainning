import React,{Component} from "react";



import Home from "./cmp/Home";



import About from "./cmp/About";



import Forms from "./cmp/Forms";



import {Route} from 'react-router-dom';



import {Routes} from 'react-router-dom';



import { Link } from "react-router-dom";






class App extends Component {



  render() {



    return (



      <div className="App">



        <Link to="/home">Home</Link>

       <br></br>



        <Link to="/about">About</Link>
        <br></br>




        <Link to="/forms">Forms</Link>



        <Routes>






          <Route exact path='/home' element={<Home />} />



          <Route exact path='/about' element={<About />} />



          <Route exact path='/forms' element={<Forms />} />



        </Routes>



      </div>



    );



  }





}









export default App;