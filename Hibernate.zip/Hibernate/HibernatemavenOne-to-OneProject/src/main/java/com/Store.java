package com;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


import com.mysql.cj.xdevapi.SessionFactory;

public class Store {    
	public static void main(String[] args) {    
	      
	    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    org.hibernate.SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	      
	    org.hibernate.Transaction t=session.beginTransaction();   
	      
	    Employee e1=new Employee();    
	    e1.setName("Garima chouhan");    
	    e1.setEmail("garima@gmail.com");    
	        
	    Address address1=new Address();    
	    address1.setAddressLine1("99,surana nagar");    
	    address1.setCity("Barwaha");    
	    address1.setState("MP");    
	    address1.setCountry("India");    
	    address1.setPincode(45115);    
	        
	    e1.setAddress(address1);    
	    address1.setEmployee(e1);    
	        
	    session.persist(e1);    
	    t.commit();    
	        
	    session.close();    
	    System.out.println("success");    
	}    
	}    