import java.util.Scanner; 
class PalindromeStringWhile
{
    public static void main(String args[])
    {
        String a ="";
        String b ="";
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the string :");
        a = s.nextLine();
        
        int temp=1;
        int rev=0,rem;


while(temp!=0)
{
   rem=temp%10;
  rev=rev*10+rem;
   temp=temp/10;


}

if(a.equalsIgnoreCase(b))
        {
            System.out.println("This string is palindrome.");
        }
        else
        {
            System.out.println("This string is not palindrome.");
        }
    }
}