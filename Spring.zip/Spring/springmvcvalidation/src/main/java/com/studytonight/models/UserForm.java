package com.studytonight.models;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
public class UserForm {

	@NotEmpty(message = "Name can not empty")
	String name;
	String lastName;
	@NotEmpty(message = "Email can not empty")
	@Email
	String email;

	public UserForm(String name, String lastName, String email) {
		this.name = name;
		this.lastName = lastName;
		this.email = email;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}