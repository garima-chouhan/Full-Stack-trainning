import java.io.ByteArrayInputStream;
import java.io.IOException;  
public class ByteArrayInputStreamExample {  
  public static void main(String[] args) throws IOException {  
    byte[] arr = { 35, 36, 37, 38 };  
     
    ByteArrayInputStream b = new ByteArrayInputStream(arr);  
    int i = 0;  
    while ((i = b.read())!= -1) {  
      
      char ch = ((char) i);  
      System.out.println("ASCII value is:" + i + "; Special character is: " + ch);  
    }  
  }  
}  