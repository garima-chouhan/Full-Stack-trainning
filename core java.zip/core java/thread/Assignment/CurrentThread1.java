public class CurrentThread1 extends Thread
{

public void run()
{
	
System.out.println("run:"+Thread.currentThread().getName());
}
public static void main(String args[])
{
System.out.println("run:"+Thread.currentThread().getName());
 CurrentThread1 ct=new CurrentThread1();
 ct.setName("hey");
 ct.start();
}
}