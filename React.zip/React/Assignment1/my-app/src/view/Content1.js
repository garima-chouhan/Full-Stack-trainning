import React, {Component} from 'react';

class Content1 extends React.Component

{

render()

{

    return(

        <div>

            <h3 class="login1">LOGIN</h3>
           <fieldset >
            <form class="button">
            <label>Email* </label>
            <input type="text" name="email" size="15"></input>
            <br></br><br></br>
            <label>Password* </label>
            <input type="password" name="password" size="15"></input><br></br><br></br>
            <input  type="button" value="submit"/>
            </form>
           </fieldset>

        </div>

    );

}



}

export default Content1;