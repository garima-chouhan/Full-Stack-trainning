class Exception extends Throwable{
Exception(String s){
super(s);
}
}
 class ThrowsCheckedException
{
public static void main(String[] args)   
 {
try
{
System.out.println("Now exception is being raised");
throw new MyCustomeException("Custom exception is thrown");
}
catch(Exception e){
System.out.println("Here exception is caught and handled");
}
}
}
