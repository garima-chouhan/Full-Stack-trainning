import java.util.Arrays;
 
public class SplitString
{
    public static void main(String[] args) {
        String str = "C\nC++\nJava\nPython\nPHP";
 
        String[] lines = str.split("\r?\n");
        System.out.println(Arrays.asList(lines));
    }
}
