import java.util.Scanner;
 
class Square {
 
    
    public static void main(String[] arg)
    {
        
        int number;
        int num;
        
        Scanner sc = new Scanner(System.in);
 
        while (true) {
 
           
            System.out.println("Enter any valid Integer: ");
 
            
            try {
 
                
                number = Integer.parseInt(sc.next());
                 num= number*number;
               
                System.out.println("The square "
                                   + num);
 
                
                break;
            }
 
           
            catch (NumberFormatException e) {
 
                
                System.out.println("NumberFormatException occurred");
            }
        }
    }
}