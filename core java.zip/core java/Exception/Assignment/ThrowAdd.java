import java.util.Scanner;

class Add extends RuntimeException
{
Add (String s)
{
super(s);
}

}

class ThrowAdd
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);


try
{
	int a=100,b=0,c;
	c=a+b;
	System.out.println(c);
catch(ArithmeticException,NullPointerException e)
{
	e.printStackTrace();
	
}
System.out.println("normal");		
	
}

}
}