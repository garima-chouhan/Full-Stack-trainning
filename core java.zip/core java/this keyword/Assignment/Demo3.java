class Demo3{
 
 Demo3()
{
this(10);
 System.out.println("No argument constructor");

}

Demo3(int a)
{
  
System.out.println("perameterised constructor");
}

public static void main(String args[])
{
Demo3 d= new Demo3();


}
}