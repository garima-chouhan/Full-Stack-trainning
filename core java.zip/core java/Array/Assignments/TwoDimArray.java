class TwoDimArray{
 public static void main(String args [])
{
 
  int[][] a=new int[4][4];
  a[0][0]=10;
  a[0][1]=20;
  a[0][2]=30;
  a[0][3]=40;
  a[1][0]=10;
  a[1][1]=20;
  a[1][2]=30;
  a[1][3]=40;
  

  int sum=0;
 for(int i=0;i<a.length;i++)
{
   for(int j=0;j<a[i].length;j++)
{
  sum=sum+a[i][j];
  System.out.println(sum); 
}
}
   
}
}