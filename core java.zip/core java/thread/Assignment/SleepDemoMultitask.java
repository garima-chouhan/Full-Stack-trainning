public class SleepDemoMultitask extends Thread
{
  public void run()
  {
  try
  {
  for(int i=1; i<=4; i++)
  {
  //Thread.sleep(-1);//illegalArgumentException..value is negative//intrrupted
  Thread.sleep(2000);
  System.out.println(i);
  }
  }
  catch(Exception e)
  {
 System.out.println(e);
  }
  }
  
public static void main(String args[])
{
  
  SleepDemoMultitask s=new SleepDemoMultitask();
  s.setName("Garima");
  s.setPriority(5);
  s.start();
  
  SleepDemoMultitask s1=new SleepDemoMultitask();
  s1.setName("Garima");
  s1.setPriority(5);
  s1.start();

}
}
