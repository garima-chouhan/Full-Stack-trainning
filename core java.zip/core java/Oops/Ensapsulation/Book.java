  class Author {

    private String name;
    private String email;
    char gender;  
    
    Author (String name,char gender, String email)
    {
        this.name = name;
        this.gender = gender;
        this.email=email;   
    }
    
    public String getName(){
        return name;  
    }
    public String getEmail(){
        return email;
    }
   public char getGender(){

    return gender;
}
}
 class Book extends Author {

    
    private Author author;
    private String name;
    private double price;
    private int qtylnstock;

    
     Book(String name,String email,char gender,double price, int qtylnstock )
    {
        this.name = name;
        this.price=price;
        this.qtylnstock = qtylnstock;
            
    }

      public Author getAuthorsName(){
       return this.author;
   }
        public String getName(){
        return name;
    }

     public double getPrice(){
        return price;
    }

    public int getQtyLnsStock(){
        return qtylnstock;
    }

   
    public void setAuthor(Author newAuthor){
        author=newAuthor;
    }
    public void setName (String name){
        this.name=name;
    }
    public void setPrice(int price){
        this.price=price;
    }
    public void setQtyInStock(int qtylnstock){
        this.qtylnstock=qtylnstock;
    }

    public String toString()
{
        return "name: " + this.name + "  "+"Author: " + this.author + "  " +
               "price: " + price + "  " + "qtylnstock: " + this.qtylnstock;
    }
}
 