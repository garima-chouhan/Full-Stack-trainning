import java.util.Iterator;
import java.util.Vector;

class Employee {
	 int id;
	 String name;
	String address;
	 Double salary;
	
	Employee(int id, String name, String address, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	
	
	public int getId() {
		return id;
	}

	
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", salary=" + salary + "]";
	}
}

public class AssignmentEmployee {

	public static void main(String[] args) {
		Vector<Employee> list = new Vector<>();
		
		list.add(new Employee(101, "Garima", "123 surana nagar, India", 20000.0));
		list.add(new Employee(102, "Gourav", "234 surana nagar, India", 30000.0));
		list.add(new Employee(103, "Pooja", "345 surana nagar, India", 25000.0));
		list.add(new Employee(104, "Amit", "456 surana nagar, India", 40000.0));
		list.add(new Employee(105, "Rahul", "678 surana nagar, India", 50000.0));
		list.add(new Employee(104, "Ajay", "246 surana nagar, India", 40000.0));
		
		Iterator<Employee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}
}