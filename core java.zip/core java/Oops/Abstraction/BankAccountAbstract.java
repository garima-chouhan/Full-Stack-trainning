 abstract class GeneralBank {

	public abstract double getSavingInterestRate();
	
	public abstract double getFixedInterestRate();
}

 class ICICIBank extends GeneralBank {

	
	public double getSavingInterestRate() {
		return 4.0;
	}

	
	public double getFixedInterestRate() {
		return 8.5;
	}

}

 class SBI extends GeneralBank {

	
	public double getSavingInterestRate() {
		return 6.0;
	}

	
	public double getFixedInterestRate() {
		return 9.0;
	}

}

 class BankAccountAbstract {

	public static void main(String[] args) {
		ICICIBank iciciBank = new ICICIBank();
		SBI sbi = new SBI();
        
		System.out.println("Saving interest rate in ICICI Bank is -"+iciciBank.getSavingInterestRate());
		System.out.println("Fixed interest rate in  ICICI Bank is -"+iciciBank.getFixedInterestRate());
		System.out.println("Saving interest rate in SBI Bank is - "+sbi.getSavingInterestRate());
		System.out.println("Fixed interest rate in SBI Bank is -"+ sbi.getFixedInterestRate());
		
		GeneralBank gb1 = new ICICIBank();
		GeneralBank gb2 = new KotMBank();
		
		System.out.println("Saving interest |ICICI Bank| - "+ gb1.getSavingInterestRate());
		System.out.println("Fixed interest |ICICI Bank| - "+ gb1.getFixedInterestRate());
		System.out.println("Saving interest |SBI Bank| - "+ gb2.getSavingInterestRate());
		System.out.println("Fixed interest |SBI Bank| - "+ gb2.getFixedInterestRate());
	}

}