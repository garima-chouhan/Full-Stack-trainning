class Demo2
{
 void display()
{
System.out.println("hello");

}
 
void show()
{
 display();

}

public static void main(String args[])
{
 Demo2 d= new Demo2();
 d.show();

}
}