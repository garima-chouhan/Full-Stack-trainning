enum Session {
   SUMMAR,WINTER,MANSOON,SPRING;
}
public class EnumSession {
   public static void main(String args[]){
      Session s;
      s = Session.WINTER;
      switch(s) {
         case SUMMAR:
            System.out.println("You choose SUMMAR");
            break;
         case WINTER:
            System.out.println("You choose WINTER");
            break;
         case MANSOON:
            System.out.println("You choose MANSOON");
            break;
         case SPRING:
            System.out.println("You choose SPRING");
            break;
         
         default:
            System.out.println("You choose RAINY");
            break;
      }
   }
}