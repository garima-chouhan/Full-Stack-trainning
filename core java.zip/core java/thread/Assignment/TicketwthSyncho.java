class BookTicket
{
int totalseats=14;
synchronized void bookseat(int seats)
{
if(totalseats>=seats)
{
System.out.println("Book successfully");
totalseats=totalseats-seats;
System.out.println("Remaining seats" +totalseats);
}
else
{
System.out.println("seats are not available:" +totalseats);
}
}

}

public class TicketwthSyncho extends Thread
{
   static BookTicket b;
   int seats;
   public void run()
   {
   b.bookseat(seats);
   }
   
   public static void main(String args[])
   {
   b=new BookTicket();
   TicketwthSyncho p1=new TicketwthSyncho();
   p1.seats=6;
   p1.start();
   
   TicketwthSyncho p2=new TicketwthSyncho();
   p2.seats=10;
   p2.start();
   
   }

}