
class PrimeNo{
public static void main(String args[])
{
 int num=Integer.parseInt(args[0]);
 boolean flag=false;
 for(int i=1;i<=num/2;i++)
 if(num%1==0){
   flag=true;
  break;


}
if(!flag)
System.out.println(num +"prime no");
 
else
System.out.println(num +"not prime");
}


}