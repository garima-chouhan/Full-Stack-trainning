class NoArgumentConstructor
{
 int a;
 
private NoArgumentConstructor()
{
 a=10;

System.out.println("NoArgument value is");
}

public static void main(String args[])
{
 
  NoArgumentConstructor n=new NoArgumentConstructor();

 
 System.out.println("Value of a=" +n.a);
}

}