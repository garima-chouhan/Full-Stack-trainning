import java.io.IOException;
import java.io.File;
class FileCreate
{
public static void main(String args[]) throws IOException
{
File f=new File("d:/yash/abc.txt");
f.createNewFile();

System.out.println(f.exists());//check exist or not
System.out.println(f.canWrite());
System.out.println(f.getName());//file name
System.out.println(f.length());//length
//f.delete();// delete file


}


}