public class CurrentThread {
public static void main(String args[])
{
 System.out.println(Thread.currentThread().getName());
 Thread.currentThread().setName(" Set the Thread");
 System.out.println(Thread.currentThread().getName());

}

}