class TwoReverseArray
{
  public static void main(String agrs[])
  {
   int a[][]=new int[2][2];
 if(a<2)
{
 System.out.println("Enter 4 values");
}
if(a==2)
{
int k=0;
for(int i=0;i<2;i++)
{
for(int j=0;j<2;j++)
{
 arr[i][j]=Integer.parseInt(args[k]);
k++;

}
}
System.out.println("The given array is");
  for(int i=0;i<2;i++)
{
  for(int j=0;j<2;j++)
{
System.out.println(arr[i][j]+"");

}
System.out.println();
}
System.out.println("the reverse of array is");
 for(int i=1;i>0;i--)
{
  for(int j=1;j>0;j--)
{
System.out.println(arr[i][j]+"");

}
System.out.println();
}
 
}
}
}