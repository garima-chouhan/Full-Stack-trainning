import java.sql.*;
import java.util.*;
class StatementExample{
public static void main(String args[])throws Exception{
class.forName("com.mysql.jdbc.Driver");
System.out.println("Driver loaded");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stu_record","root","root");
System.out.println("Connection Established");

Statement st = con.createStatement();
ResultSet rs = st.executeQuery("select * from traning");

System.out.println("Rollno  Student_Name  sub  Percentage");
System.out.println("------------------------------------------");
while(rs.next())
{
System.out.println(rs.getInt(1)+ " " +rs.getString(2)+ " " +rs.getString(3)+ " "+rs.getFloat(4));
}
}
}