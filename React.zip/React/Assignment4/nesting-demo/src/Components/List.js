import React from 'react'



const List = () => {

return (

    <div className='List'>

    <h2>You are inside the List Component</h2>

    <h4>URL: localhost:3000/courses/list</h4>

    </div>

)

}



export default List