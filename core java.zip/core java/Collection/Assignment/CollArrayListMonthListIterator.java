import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Iterator;
class CollArrayListMonthListIterator {

public static void main(String[] args)
{

ArrayList<String> s = new ArrayList<String>();


s.add("JANUARY");
s.add("FEB");
s.add("MARCH");
s.add("APRIL");
s.add("MAY");
s.add("JUNE");
s.add("JULY");
s.add("AGU");
s.add("SEP");
s.add("OCT");
s.add("NOV");
s.add("DEC");
System.out.println(s);

ListIterator li = s.ListIterator();
li.next();

while(li.hasPrevious())
{
	System.out.println(li.Previous());
}

for(String j:s)
{
	
System.out.println("months of the year"+" " + j);	
}
}
}