public class SinThreadMultiple extends Thread{
       public void run()
	   {
	      System.out.println("Thread Started");
		  }
		  public static void main(String[] args)
		  {
		     SinThreadMultiple td = new SinThreadMultiple();
			 td.start();
			 SinThreadMultiple td1 = new SinThreadMultiple();
			 td1.start();
			 SinThreadMultiple td2 = new SinThreadMultiple();
			 td2.start();
			 }
	}