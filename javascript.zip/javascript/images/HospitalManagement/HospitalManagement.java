<!DOCTYPE html>
<!-- saved from url=(0070)https://www.codespeedy.com/hospital-management-system-using-core-java/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="https://static.criteo.net/js/ld/publishertag.prebid.js"></script><script async="" type="text/javascript" src="./HospitalManagement_files/cmp2.js.download"></script><script type="text/javascript" async="" src="./HospitalManagement_files/analytics.js.download"></script><script type="text/javascript" async="" src="./HospitalManagement_files/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-u58lmaqnNN/mK+75qtMhq1v5qJ4VVlBXBCJoUO+w4/lUH+f065BssRD9I8gNvIhn"></script><script async="" type="text/javascript" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"></script><script async="" src="https://c.amazon-adsystem.com/aax2/apstag.js"></script><script async="" type="text/javascript" src="./HospitalManagement_files/prebid.js.download"></script><script async="" type="text/javascript" src="./HospitalManagement_files/choice.js.download"></script><script>if(navigator.userAgent.match(/MSIE|Internet Explorer/i)||navigator.userAgent.match(/Trident\/7\..*?rv:11/i)){var href=document.location.href;if(!href.match(/[?&]nowprocket/)){if(href.indexOf("?")==-1){if(href.indexOf("#")==-1){document.location.href=href+"?nowprocket=1"}else{document.location.href=href.replace("#","?nowprocket=1#")}}else{if(href.indexOf("#")==-1){document.location.href=href+"&nowprocket=1"}else{document.location.href=href.replace("#","&nowprocket=1#")}}}}</script><script>class RocketLazyLoadScripts{constructor(){this.triggerEvents=["keydown","mousedown","mousemove","touchmove","touchstart","touchend","wheel"],this.userEventHandler=this._triggerListener.bind(this),this.touchStartHandler=this._onTouchStart.bind(this),this.touchMoveHandler=this._onTouchMove.bind(this),this.touchEndHandler=this._onTouchEnd.bind(this),this.clickHandler=this._onClick.bind(this),this.interceptedClicks=[],window.addEventListener("pageshow",(e=>{this.persisted=e.persisted})),window.addEventListener("DOMContentLoaded",(()=>{this._preconnect3rdParties()})),this.delayedScripts={normal:[],async:[],defer:[]},this.allJQueries=[]}_addUserInteractionListener(e){document.hidden?e._triggerListener():(this.triggerEvents.forEach((t=>window.addEventListener(t,e.userEventHandler,{passive:!0}))),window.addEventListener("touchstart",e.touchStartHandler,{passive:!0}),window.addEventListener("mousedown",e.touchStartHandler),document.addEventListener("visibilitychange",e.userEventHandler))}_removeUserInteractionListener(){this.triggerEvents.forEach((e=>window.removeEventListener(e,this.userEventHandler,{passive:!0}))),document.removeEventListener("visibilitychange",this.userEventHandler)}_onTouchStart(e){"HTML"!==e.target.tagName&&(window.addEventListener("touchend",this.touchEndHandler),window.addEventListener("mouseup",this.touchEndHandler),window.addEventListener("touchmove",this.touchMoveHandler,{passive:!0}),window.addEventListener("mousemove",this.touchMoveHandler),e.target.addEventListener("click",this.clickHandler),this._renameDOMAttribute(e.target,"onclick","rocket-onclick"))}_onTouchMove(e){window.removeEventListener("touchend",this.touchEndHandler),window.removeEventListener("mouseup",this.touchEndHandler),window.removeEventListener("touchmove",this.touchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",this.touchMoveHandler),e.target.removeEventListener("click",this.clickHandler),this._renameDOMAttribute(e.target,"rocket-onclick","onclick")}_onTouchEnd(e){window.removeEventListener("touchend",this.touchEndHandler),window.removeEventListener("mouseup",this.touchEndHandler),window.removeEventListener("touchmove",this.touchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",this.touchMoveHandler)}_onClick(e){e.target.removeEventListener("click",this.clickHandler),this._renameDOMAttribute(e.target,"rocket-onclick","onclick"),this.interceptedClicks.push(e),e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()}_replayClicks(){window.removeEventListener("touchstart",this.touchStartHandler,{passive:!0}),window.removeEventListener("mousedown",this.touchStartHandler),this.interceptedClicks.forEach((e=>{e.target.dispatchEvent(new MouseEvent("click",{view:e.view,bubbles:!0,cancelable:!0}))}))}_renameDOMAttribute(e,t,n){e.hasAttribute&&e.hasAttribute(t)&&(event.target.setAttribute(n,event.target.getAttribute(t)),event.target.removeAttribute(t))}_triggerListener(){this._removeUserInteractionListener(this),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",this._loadEverythingNow.bind(this)):this._loadEverythingNow()}_preconnect3rdParties(){let e=[];document.querySelectorAll("script[type=rocketlazyloadscript]").forEach((t=>{if(t.hasAttribute("src")){const n=new URL(t.src).origin;n!==location.origin&&e.push({src:n,crossOrigin:t.crossOrigin||"module"===t.getAttribute("data-rocket-type")})}})),e=[...new Map(e.map((e=>[JSON.stringify(e),e]))).values()],this._batchInjectResourceHints(e,"preconnect")}async _loadEverythingNow(){this.lastBreath=Date.now(),this._delayEventListeners(),this._delayJQueryReady(this),this._handleDocumentWrite(),this._registerAllDelayedScripts(),this._preloadAllScripts(),await this._loadScriptsFromList(this.delayedScripts.normal),await this._loadScriptsFromList(this.delayedScripts.defer),await this._loadScriptsFromList(this.delayedScripts.async);try{await this._triggerDOMContentLoaded(),await this._triggerWindowLoad()}catch(e){}window.dispatchEvent(new Event("rocket-allScriptsLoaded")),this._replayClicks()}_registerAllDelayedScripts(){document.querySelectorAll("script[type=rocketlazyloadscript]").forEach((e=>{e.hasAttribute("src")?e.hasAttribute("async")&&!1!==e.async?this.delayedScripts.async.push(e):e.hasAttribute("defer")&&!1!==e.defer||"module"===e.getAttribute("data-rocket-type")?this.delayedScripts.defer.push(e):this.delayedScripts.normal.push(e):this.delayedScripts.normal.push(e)}))}async _transformScript(e){return await this._littleBreath(),new Promise((t=>{const n=document.createElement("script");[...e.attributes].forEach((e=>{let t=e.nodeName;"type"!==t&&("data-rocket-type"===t&&(t="type"),n.setAttribute(t,e.nodeValue))})),e.hasAttribute("src")?(n.addEventListener("load",t),n.addEventListener("error",t)):(n.text=e.text,t());try{e.parentNode.replaceChild(n,e)}catch(e){t()}}))}async _loadScriptsFromList(e){const t=e.shift();return t?(await this._transformScript(t),this._loadScriptsFromList(e)):Promise.resolve()}_preloadAllScripts(){this._batchInjectResourceHints([...this.delayedScripts.normal,...this.delayedScripts.defer,...this.delayedScripts.async],"preload")}_batchInjectResourceHints(e,t){var n=document.createDocumentFragment();e.forEach((e=>{if(e.src){const i=document.createElement("link");i.href=e.src,i.rel=t,"preconnect"!==t&&(i.as="script"),e.getAttribute&&"module"===e.getAttribute("data-rocket-type")&&(i.crossOrigin=!0),e.crossOrigin&&(i.crossOrigin=e.crossOrigin),n.appendChild(i)}})),document.head.appendChild(n)}_delayEventListeners(){let e={};function t(t,n){!function(t){function n(n){return e[t].eventsToRewrite.indexOf(n)>=0?"rocket-"+n:n}e[t]||(e[t]={originalFunctions:{add:t.addEventListener,remove:t.removeEventListener},eventsToRewrite:[]},t.addEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.add.apply(t,arguments)},t.removeEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.remove.apply(t,arguments)})}(t),e[t].eventsToRewrite.push(n)}function n(e,t){let n=e[t];Object.defineProperty(e,t,{get:()=>n||function(){},set(i){e["rocket"+t]=n=i}})}t(document,"DOMContentLoaded"),t(window,"DOMContentLoaded"),t(window,"load"),t(window,"pageshow"),t(document,"readystatechange"),n(document,"onreadystatechange"),n(window,"onload"),n(window,"onpageshow")}_delayJQueryReady(e){let t=window.jQuery;Object.defineProperty(window,"jQuery",{get:()=>t,set(n){if(n&&n.fn&&!e.allJQueries.includes(n)){n.fn.ready=n.fn.init.prototype.ready=function(t){e.domReadyFired?t.bind(document)(n):document.addEventListener("rocket-DOMContentLoaded",(()=>t.bind(document)(n)))};const t=n.fn.on;n.fn.on=n.fn.init.prototype.on=function(){if(this[0]===window){function e(e){return e.split(" ").map((e=>"load"===e||0===e.indexOf("load.")?"rocket-jquery-load":e)).join(" ")}"string"==typeof arguments[0]||arguments[0]instanceof String?arguments[0]=e(arguments[0]):"object"==typeof arguments[0]&&Object.keys(arguments[0]).forEach((t=>{delete Object.assign(arguments[0],{[e(t)]:arguments[0][t]})[t]}))}return t.apply(this,arguments),this},e.allJQueries.push(n)}t=n}})}async _triggerDOMContentLoaded(){this.domReadyFired=!0,await this._littleBreath(),document.dispatchEvent(new Event("rocket-DOMContentLoaded")),await this._littleBreath(),window.dispatchEvent(new Event("rocket-DOMContentLoaded")),await this._littleBreath(),document.dispatchEvent(new Event("rocket-readystatechange")),await this._littleBreath(),document.rocketonreadystatechange&&document.rocketonreadystatechange()}async _triggerWindowLoad(){await this._littleBreath(),window.dispatchEvent(new Event("rocket-load")),await this._littleBreath(),window.rocketonload&&window.rocketonload(),await this._littleBreath(),this.allJQueries.forEach((e=>e(window).trigger("rocket-jquery-load"))),await this._littleBreath();const e=new Event("rocket-pageshow");e.persisted=this.persisted,window.dispatchEvent(e),await this._littleBreath(),window.rocketonpageshow&&window.rocketonpageshow({persisted:this.persisted})}_handleDocumentWrite(){const e=new Map;document.write=document.writeln=function(t){const n=document.currentScript,i=document.createRange(),r=n.parentElement;let o=e.get(n);void 0===o&&(o=n.nextSibling,e.set(n,o));const s=document.createDocumentFragment();i.setStart(s,0),s.appendChild(i.createContextualFragment(t)),r.insertBefore(s,o)}}async _littleBreath(){Date.now()-this.lastBreath>45&&(await this._requestAnimFrame(),this.lastBreath=Date.now())}async _requestAnimFrame(){return document.hidden?new Promise((e=>setTimeout(e))):new Promise((e=>requestAnimationFrame(e)))}static run(){const e=new RocketLazyLoadScripts;e._addUserInteractionListener(e)}}RocketLazyLoadScripts.run();</script> <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no"><link media="all" href="./HospitalManagement_files/autoptimize_dceeb72f9a3f82760bd298908b3835cf.css" rel="stylesheet"><title>Hospital Management System using core Java - CodeSpeedy</title><meta name="theme-color" content="#308455"><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><meta name="description" content="A Hostiptal Management project using concept of JAVA DATABASE CONNECTIVITY, OBJECT ORIENTED PROGRAMMING, SWINGS, EXCEPTION HANDLING, etc."><link rel="canonical" href="https://www.codespeedy.com/hospital-management-system-using-core-java/"><meta property="og:locale" content="en_US"><meta property="og:type" content="article"><meta property="og:title" content="Hospital Management System using core Java - CodeSpeedy"><meta property="og:description" content="A Hostiptal Management project using concept of JAVA DATABASE CONNECTIVITY, OBJECT ORIENTED PROGRAMMING, SWINGS, EXCEPTION HANDLING, etc."><meta property="og:url" content="https://www.codespeedy.com/hospital-management-system-using-core-java/"><meta property="og:site_name" content="CodeSpeedy"><meta property="article:publisher" content="https://www.facebook.com/CodeSpeedy"><meta property="article:published_time" content="2020-01-15T13:58:50+00:00"><meta property="og:image" content="https://codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java.png"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:label1" content="Written by"><meta name="twitter:data1" content="Kamalpreet Singh"><meta name="twitter:label2" content="Est. reading time"><meta name="twitter:data2" content="37 minutes"> <script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://www.codespeedy.com/#organization","name":"CodeSpeedy Technology Private Limited","url":"https://www.codespeedy.com/","sameAs":["https://www.facebook.com/CodeSpeedy","https://www.linkedin.com/company/codespeedy/","https://www.youtube.com/channel/UCMJ1lJNPDprdAH8Yo2-e1KQ"],"logo":{"@type":"ImageObject","@id":"https://www.codespeedy.com/#logo","inLanguage":"en-US","url":"https://www.codespeedy.com/wp-content/uploads/2022/02/CodeSpeedy-Logo.png","contentUrl":"https://www.codespeedy.com/wp-content/uploads/2022/02/CodeSpeedy-Logo.png","width":194,"height":169,"caption":"CodeSpeedy Technology Private Limited"},"image":{"@id":"https://www.codespeedy.com/#logo"}},{"@type":"WebSite","@id":"https://www.codespeedy.com/#website","url":"https://www.codespeedy.com/","name":"CodeSpeedy","description":"Coding solutions - PHP, Java, JS, Python","publisher":{"@id":"https://www.codespeedy.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.codespeedy.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"ImageObject","@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#primaryimage","inLanguage":"en-US","url":"https://codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java.png","contentUrl":"https://codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java.png"},{"@type":"WebPage","@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#webpage","url":"https://www.codespeedy.com/hospital-management-system-using-core-java/","name":"Hospital Management System using core Java - CodeSpeedy","isPartOf":{"@id":"https://www.codespeedy.com/#website"},"primaryImageOfPage":{"@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#primaryimage"},"datePublished":"2020-01-15T13:58:50+00:00","dateModified":"2020-01-15T13:58:50+00:00","description":"A Hostiptal Management project using concept of JAVA DATABASE CONNECTIVITY, OBJECT ORIENTED PROGRAMMING, SWINGS, EXCEPTION HANDLING, etc.","breadcrumb":{"@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://www.codespeedy.com/hospital-management-system-using-core-java/"]}]},{"@type":"BreadcrumbList","@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://www.codespeedy.com/"},{"@type":"ListItem","position":2,"name":"Hospital Management System using core Java"}]},{"@type":"Article","@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#article","isPartOf":{"@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#webpage"},"author":{"@id":"https://www.codespeedy.com/#/schema/person/44d92709eb1b9c1edb2debbcf331665b"},"headline":"Hospital Management System using core Java","datePublished":"2020-01-15T13:58:50+00:00","dateModified":"2020-01-15T13:58:50+00:00","mainEntityOfPage":{"@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#webpage"},"wordCount":1029,"commentCount":0,"publisher":{"@id":"https://www.codespeedy.com/#organization"},"image":{"@id":"https://www.codespeedy.com/hospital-management-system-using-core-java/#primaryimage"},"thumbnailUrl":"https://codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java.png","keywords":["Java project"],"articleSection":["Java"],"inLanguage":"en-US","potentialAction":[{"@type":"CommentAction","name":"Comment","target":["https://www.codespeedy.com/hospital-management-system-using-core-java/#respond"]}]},{"@type":"Person","@id":"https://www.codespeedy.com/#/schema/person/44d92709eb1b9c1edb2debbcf331665b","name":"Kamalpreet Singh","url":"https://www.codespeedy.com/author/kamalpreet_singh/"}]}</script> <link rel="dns-prefetch" href="https://cdn.codespeedy.com/"><link href="https://cdn.codespeedy.com/" rel="preconnect"><link rel="alternate" type="application/rss+xml" title="CodeSpeedy » Hospital Management System using core Java Comments Feed" href="https://www.codespeedy.com/hospital-management-system-using-core-java/feed/"> <script type="text/javascript" src="./HospitalManagement_files/jquery.min.js.download" id="jquery-core-js"></script> <script type="text/javascript" src="./HospitalManagement_files/jquery-migrate.min.js.download" id="jquery-migrate-js"></script> <link rel="https://api.w.org/" href="https://www.codespeedy.com/wp-json/"><link rel="alternate" type="application/json" href="https://www.codespeedy.com/wp-json/wp/v2/posts/29541"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.codespeedy.com/xmlrpc.php?rsd"><link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://cdn.codespeedy.com/wp-includes/wlwmanifest.xml"><meta name="generator" content="WordPress 5.9.3"><link rel="shortlink" href="https://www.codespeedy.com/?p=29541"><link rel="alternate" type="application/json+oembed" href="https://www.codespeedy.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.codespeedy.com%2Fhospital-management-system-using-core-java%2F"><link rel="alternate" type="text/xml+oembed" href="https://www.codespeedy.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.codespeedy.com%2Fhospital-management-system-using-core-java%2F&amp;format=xml"><meta name="generator" content="Easy Digital Downloads v2.11.5"><link rel="icon" href="https://cdn.codespeedy.com/wp-content/uploads/2018/07/cropped-CodeSpeedy-Logo-32x32.png" sizes="32x32"><link rel="icon" href="https://cdn.codespeedy.com/wp-content/uploads/2018/07/cropped-CodeSpeedy-Logo-192x192.png" sizes="192x192"><link rel="apple-touch-icon" href="https://cdn.codespeedy.com/wp-content/uploads/2018/07/cropped-CodeSpeedy-Logo-180x180.png"><meta name="msapplication-TileImage" content="https://cdn.codespeedy.com/wp-content/uploads/2018/07/cropped-CodeSpeedy-Logo-270x270.png"> <noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript><meta name="google-site-verification" content="SIEMot2hMW6Kw7rEB5AVuro1d3pioWiDF0No8UJZQ8M">  <script async="" src="./HospitalManagement_files/fuse.js.download"></script> <link href="./HospitalManagement_files/jquery.min.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/jquery-migrate.min.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/comment-reply.min.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/edd-ajax.min.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/enlighterjs.min.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/fuse.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/api.js.download" rel="preload" as="script"><link href="./HospitalManagement_files/js" rel="preload" as="script"><link href="https://cdn.codespeedy.com/" rel="preconnect"><link href="https://cdn.fuseplatform.net/" rel="preconnect"><link href="https://www.google.com/" rel="preconnect"><link href="https://www.googletagmanager.com/" rel="preconnect"><style type="text/css"> .qc-cmp-button.qc-cmp-secondary-button:hover {    background-color: #368bd6 !important;    border-color: transparent !important;  }  .qc-cmp-button.qc-cmp-secondary-button:hover {    color: #ffffff !important;  }  .qc-cmp-button.qc-cmp-secondary-button {    color: #368bd6 !important;  }  .qc-cmp-button.qc-cmp-secondary-button {    background-color: #eee !important;    border-color: transparent !important;  } .qc-cmp-qc-link #qcLogo { display: none;}.qc-cmp-link-text { margin: 1em 0; display: none;}</style></head><body><header><nav><div id="logo"> <a href="https://www.codespeedy.com/"> <img width="194" height="169" class="img-responsive" src="./HospitalManagement_files/CodeSpeedy-Logo.png" alt="CodeSpeedy Logo" style="display: inline; margin-top: -8px;"> <strong style="font-size: 1.4em;">CodeSpeedy</strong> </a></div> <label for="drop" class="toggle"><i class="fa fa-bars"></i> Menu</label> <input type="checkbox" id="drop"><ul class="menu"><li><a href="https://www.codespeedy.com/">Home</a></li><li><a href="https://www.codespeedy.com/online-python-compiler">Online Python Compiler</a></li><li><a href="https://www.codespeedy.com/online-swift-compiler">Online Swift Compiler</a></li><li><a rel="nofollow" href="https://www.codespeedy.com/contact-us">Contact</a></li></ul></nav><div id="end-header-mark"></div></header><div class="container-fluid cspd-post-content"><div class="col-sm-2"><div id="l-sticky-ad"></div></div><div class="col-sm-7"><div class="post-content" id="post-content"><h1 class="post-title">Hospital Management System using core Java</h1><div class="authorofpost"> <a href="https://www.codespeedy.com/author/kamalpreet_singh/"><img class="img-circle single_post_avatar" src="./HospitalManagement_files/1df6a7f1afea82aa87f1566634cf8a1c.png" width="55" height="55"> By Kamalpreet Singh</a></div><p>In this tutorial, we will learn to make a Java project ie. HOSPITAL MANAGEMENT SYSTEM. Many college or school students want to make attractive projects but due to insufficient knowledge are not able to make the project as desired.</p><p>so in this tutorial, we will learn to make the project from scratch.</p><p>For creating a java project we can use notepad, eclipse, Netbeans, etc.</p><div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180" data-fuse-code="fuse-slot-22688779180-1" data-fuse-slot="fuse-slot-22688779180-1" data-fuse-processed-at="6074"><div id="fuse-slot-22688779180-1" class="fuse-slot"></div></div></div><p>It is very easy for us to make the project without a graphical user interface, but in this tutorial, we will learn to make the project using the graphical user interface.</p><p>As we all know a project consists of front end and backend.&nbsp; For Frontend we will use swings. And For Backend, we will use core java concepts ie. JDBC(Java database connectivity), packages, etc.</p><p>HOSPITAL MANAGEMENT SYSTEM as the name suggests is the software that manages the working of hospitals.</p><h2 style="text-align: center;">operations that we can perform using project</h2><p>1. First of all, we will receive a login form in which we can either log in as staff or a doctor by adding username and password.</p><p>2. If entered username or password is correct then we will receive a dialogue box welcome staff or welcome doctor. clicking ok on dialogue box will lead us to the staff or doctor’s dashboard. If the username or password is incorrect we will receive a dialogue box Invalid username or password.</p><p>3. At the staff dashboard, we will receive several operations for example: ADD STAFF, ADD DOCTOR, PREPARE BILL, ADD PATIENT, ADD TEST, APPOINTMENT, VIEW DOCTOR, UPDATE DOCTOR, BILL, VIEW DOCTOR, VIEW STAFF, VIEW PATIENT, UPDATE PATIENT, etc.</p><p>4. At the doctor’s dashboard, we will receive other options like ADD TEST, ADD PATIENT, VIEW TEST, VIEW PATIENTS, etc.</p><p>5. There will be one java page for the connection of Netbeans with Mysql.</p><div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180" data-fuse-code="fuse-slot-22688779180-2" data-fuse-slot="fuse-slot-22688779180-2" data-fuse-processed-at="6074"><div id="fuse-slot-22688779180-2" class="fuse-slot"></div></div></div><p>All the data entered will be stored in the form of tables using MySQL.</p><p>&nbsp;</p><div class="enlighter-default enlighter-v-standard enlighter-t-atomic enlighter-hover enlighter-linenumbers enlighter-overflow-scroll "><div class="enlighter-toolbar-top enlighter-toolbar"><div class="enlighter-btn enlighter-btn-raw" title="Plain text"></div><div class="enlighter-btn enlighter-btn-copy" title="Copy to clipboard"></div><div class="enlighter-btn enlighter-btn-window" title="Open code in new window"></div><div class="enlighter-btn enlighter-btn-website" title="EnlighterJS 3 Syntax Highlighter"></div></div><div class="enlighter" style=""><div class=""><div><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JFrame</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> hmsproject </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">         </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con=Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps=</span><span class="enlighter-e1">null</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">staffr.</span><span class="enlighter-m3">isSelected</span><span class="enlighter-g1">()){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                ps=con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from staff where uname=? and pwd=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">,namer.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                 ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">,pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ResultSet rs=ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">()){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                      JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Welcome STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    Staffdashboard sd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Staffdashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    sd.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span><span class="enlighter-c0"> //to open new frame ad</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                   </span><span class="enlighter-c0"> //invalid admin</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Invalid Uname or Password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hmsproject hms = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hms.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span><span class="enlighter-c0"> //to open new frame ad</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;            </span><span class="enlighter-c0"> //to close current frame</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-k1">else</span><span class="enlighter-text"> </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">doctorr.</span><span class="enlighter-m3">isSelected</span><span class="enlighter-g1">())</span><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">                ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from doctor where uname=? and pwd=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, namer.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ResultSet rs=ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">,</span><span class="enlighter-s0">"welocome DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    Doctordashboard td =</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Doctordashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    td.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">,</span><span class="enlighter-s0">"Invalid username and password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hmsproject hms = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hms.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text">  </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">ButtonGroup</span><span class="enlighter-text"> buttonGroup1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-text"> doctorr;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> namer;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-text"> staffr;</span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    ------------------------------------------------------------------------------------------------------------------------------    </span></div></div><div class=""><div><span class="enlighter-text">Addpatient.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Addpatient </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">   </span><span class="enlighter-c0"> // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          </span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        age1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        disease = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        phone_number = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        guardian = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        uname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ADD NEW PATIENT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"NAME "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"AGE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"DISEASE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PHONE NUMBER"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"GUARDIAN"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        age1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">age1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        disease.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">diseaseActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        guardian.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">guardianActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"SUBMIT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"CLEAR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"uname"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">age1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">guardianActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">diseaseActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                       </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">         </span><span class="enlighter-k1">try</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"insert into patient(name1,age1,disease,phone_number,guardian,uname,pwd) values(?,?,?,?,?,?,?)"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name1.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, age1.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, disease.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, phone_number.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-text">, guardian.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-text">, uname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-text">, pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">x </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text"> </span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Patient Added"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Addpatient ap = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ap.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">name1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">age1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">disease.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">phone_number.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">guardian.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">for</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">LookAndFeelInfo</span><span class="enlighter-text"> info : javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">getInstalledLookAndFeels</span><span class="enlighter-g1">())</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Nimbus"</span><span class="enlighter-text">.</span><span class="enlighter-m0">equals</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">()))</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">setLookAndFeel</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getClassName</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k1">break</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> Exception ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">({</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addpatient.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">InstantiationException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addpatient.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">IllegalAccessException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addpatient.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UnsupportedLookAndFeelException</span><span class="enlighter-text"> ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addpatient.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> age1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> disease;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> guardian;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> phone_number;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> uname;</span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">--------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Addstaff.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Addstaff </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text">                          </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        age = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        qualification = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        address = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        phone = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        uname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ADD NEW STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"AGE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"QUALIFICATION"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ADDRESS"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PHONE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"SUBMIT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"CLEAR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"uname "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"jPasswordField1"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"insert into staff(name,age,qualification,address,phone,uname,pwd) values(?,?,?,?,?,?,?)"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, age.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, qualification.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, address.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-text">, phone.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-text">, uname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-text">, pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">x </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text"> </span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Staff Added"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Addstaff as = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                as.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">name.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">age.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">qualification.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">address.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">phone.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">uname.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">for</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">LookAndFeelInfo</span><span class="enlighter-text"> info : javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">getInstalledLookAndFeels</span><span class="enlighter-g1">())</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Nimbus"</span><span class="enlighter-text">.</span><span class="enlighter-m0">equals</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">()))</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">setLookAndFeel</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getClassName</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k1">break</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">ClassNotFoundException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addstaff.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">InstantiationException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addstaff.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">IllegalAccessException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addstaff.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UnsupportedLookAndFeelException</span><span class="enlighter-text"> ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Addstaff.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">     </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> address;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> age;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> phone;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> qualification;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> uname;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">----------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Addtest.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Addtest </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addtest</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text">                          </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">ButtonGroup</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        DOOCTOR = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        fees = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        desc1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        doct = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ADD NEW TEST"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"TEST NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"TEST FEES"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"DESCRIPTION"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        DOOCTOR.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"SAVE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jButton1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"CLEAR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jButton2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        desc1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">desc1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">          </span><span class="enlighter-k1">try</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"insert into test(name1,fees,desc1,doct) values(?,?,?,?)"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name1.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, fees.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, desc1.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, doct.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">x </span><span class="enlighter-g1">&gt;</span><span class="enlighter-text"> </span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"TEST Added"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Adddoctor ad = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Adddoctor</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ad.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">      name1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">      fees.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">      desc1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">      doct.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">desc1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                      </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">     </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addtest</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                         </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> DOOCTOR;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">ButtonGroup</span><span class="enlighter-text"> buttonGroup1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> desc1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> doct;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> fees;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name1;</span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">---------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Appointment.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.text.SimpleDateFormat</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.util.Date</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Appointment </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Appointment</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                            </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        dname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        page = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"appointment"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"patient's name"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"doctor's name"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"patient's age"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" will text you the timings of appointment as soon as possible "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"submit"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                              </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"insert into appointment(name,dname,page,date) values(?,?,?,?)"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, dname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, page.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">            Date d = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Date</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              SimpleDateFormat sd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">SimpleDateFormat</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"yyyy-MM-dd"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-k5">String</span><span class="enlighter-text"> dd = sd.</span><span class="enlighter-m3">format</span><span class="enlighter-g1">(</span><span class="enlighter-text">d</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, dd</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">x</span><span class="enlighter-g1">&gt;</span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                  JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"APPOINTMENT PROCESSED"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  Appointment ad = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Appointment</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  ad.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">for</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">LookAndFeelInfo</span><span class="enlighter-text"> info : javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">getInstalledLookAndFeels</span><span class="enlighter-g1">())</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Nimbus"</span><span class="enlighter-text">.</span><span class="enlighter-m0">equals</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">()))</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UIManager</span><span class="enlighter-text">.</span><span class="enlighter-m3">setLookAndFeel</span><span class="enlighter-g1">(</span><span class="enlighter-text">info.</span><span class="enlighter-m3">getClassName</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k1">break</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">ClassNotFoundException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Appointment.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">InstantiationException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Appointment.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">IllegalAccessException ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Appointment.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span><span class="enlighter-k1">catch</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">UnsupportedLookAndFeelException</span><span class="enlighter-text"> ex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Logger</span><span class="enlighter-text">.</span><span class="enlighter-m3">getLogger</span><span class="enlighter-g1">(</span><span class="enlighter-text">Appointment.</span><span class="enlighter-m3">class</span><span class="enlighter-text">.</span><span class="enlighter-m3">getName</span><span class="enlighter-g1">())</span><span class="enlighter-text">.</span><span class="enlighter-m3">log</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">util</span><span class="enlighter-text">.</span><span class="enlighter-m3">logging</span><span class="enlighter-text">.</span><span class="enlighter-m3">Level</span><span class="enlighter-text">.</span><span class="enlighter-m3">SEVERE</span><span class="enlighter-text">, </span><span class="enlighter-e1">null</span><span class="enlighter-text">, ex</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Appointment</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> dname;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> page;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Bill.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Bill </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Bill</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        a = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        b = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        c = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        g = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Bill of patient"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ENTER NUMBER OF DAYS PATIENT WAS ADMITTED"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ENTER  TOTAL COST OF TESTS"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ENTER TOTAL FEES OF DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        b.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">bActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"GENERATE BILL"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">     </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">bActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                  </span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                 </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">int</span><span class="enlighter-text"> d=</span><span class="enlighter-k5">Integer</span><span class="enlighter-text">.</span><span class="enlighter-m3">parseInt</span><span class="enlighter-g1">(</span><span class="enlighter-text">a.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;  </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">int</span><span class="enlighter-text"> e=</span><span class="enlighter-k5">Integer</span><span class="enlighter-text">.</span><span class="enlighter-m3">parseInt</span><span class="enlighter-g1">(</span><span class="enlighter-text">b.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">; </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">int</span><span class="enlighter-text"> f=</span><span class="enlighter-k5">Integer</span><span class="enlighter-text">.</span><span class="enlighter-m3">parseInt</span><span class="enlighter-g1">(</span><span class="enlighter-text">c.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">int</span><span class="enlighter-text"> m=d*</span><span class="enlighter-n1">5000</span><span class="enlighter-text">+e+f;</span></div></div><div class=""><div><span class="enlighter-text">g.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">m+</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span><span class="enlighter-c0"></span></div></div><div class=""><div><span class="enlighter-c0">// TODO add your handling code here:</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">      </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Bill</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> a;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> b;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> c;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> g;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Connection.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.DriverManager</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Connectiondb </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> Connection </span><span class="enlighter-m0">getConnection</span><span class="enlighter-g1">(){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        Connection con=</span><span class="enlighter-e1">null</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Class.</span><span class="enlighter-m3">forName</span><span class="enlighter-text"> </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"com.mysql.jdbc.Driver"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            con=DriverManager.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"jdbc:mysql://localhost:3306/hms"</span><span class="enlighter-text">,</span><span class="enlighter-s0">"id"</span><span class="enlighter-text">,</span><span class="enlighter-s0">"password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k0">return</span><span class="enlighter-text"> con;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">--------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Doctordashboard.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Doctordashboard </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  /</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Doctordashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuBar</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"WELCOME DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"File"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"viewtest"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Addtest"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"patients"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"add patient"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem4ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"update patient"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem5ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem5</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"jMenuItem6"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem6</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenu1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenu2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Edit"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenu2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setJMenuBar</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuBar1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">viewtest</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        :</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;      </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addtest</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem4ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem5ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatepatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Doctordashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-text"> jMenu1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-text"> jMenu2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuBar</span><span class="enlighter-text"> jMenuBar1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem6;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">Staffdashboard.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Staffdashboard </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Staffdashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuBar</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem9 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem10 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem11 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem12 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"welcome staff"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"File"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Add doctor"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Add staff"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Add patient"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem3.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Add test"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem4.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem4ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"appointmemts"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem5.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem5ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem5</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"view doctor"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem6.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem6ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem6</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Update doctor"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem7.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem7ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem7</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"BILL"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem8.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem8ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem8</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem9.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"VIEW DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem9.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem9ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem9</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem10.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"VIEW PATIENT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem10.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem10ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem10</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem11.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"VIEW STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem11.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem11ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem11</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem12.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE PATIENT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuItem12.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jMenuItem12ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenu1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuItem12</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenu1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jMenu2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"Edit"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jMenuBar1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenu2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setJMenuBar</span><span class="enlighter-g1">(</span><span class="enlighter-text">jMenuBar1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Adddoctor</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem4ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Addtest</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem5ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Appointment</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem6ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewdoctor_1</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem7ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatedoctor</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem8ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Bill</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem9ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewdoctor_1</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem10ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                            </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem11ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                            </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jMenuItem12ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                            </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatepatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                           </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Staffdashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-text"> jMenu1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenu</span><span class="enlighter-text"> jMenu2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuBar</span><span class="enlighter-text"> jMenuBar1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem10;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem11;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem12;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JMenuItem</span><span class="enlighter-text"> jMenuItem9;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Updatedoctor.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Updatedoctor </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatedoctor</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        adm = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        age = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        qualification = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        address = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel9 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        phone = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        uname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"USER NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"search"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"clear"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"name"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"age"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"qualification"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"address"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"phone"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"uname"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel9.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"pwd"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"submit"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton3.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                         </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">String</span><span class="enlighter-text"> userName = adm.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from doctor where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">,userName</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">              </span></div></div><div class=""><div><span class="enlighter-text">                adm.</span><span class="enlighter-m3">setEditable</span><span class="enlighter-g1">(</span><span class="enlighter-e0">false</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               </span></div></div><div class=""><div><span class="enlighter-text">                name.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                age.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                qualification.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                address.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                phone.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                adm.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Invalid User Name !!"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">              </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">                              </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">     uname.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">" "</span><span class="enlighter-g1">)</span><span class="enlighter-text"> ;       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">       </span><span class="enlighter-k1">try</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">             </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"update doctor set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, age.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, qualification.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, address.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-text">,phone.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-text">, uname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-text">,pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">x</span><span class="enlighter-g1">&gt;</span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"DOCTOR Details updated"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Updatestaff as = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatestaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                as.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatedoctor</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> address;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> adm;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> age;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel9;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> phone;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> qualification;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> uname;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Updatepatient.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Updatepatient </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatepatient</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                         </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        adm = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel9 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel10 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        age = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        disease = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        phone_number = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        guardian = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        uname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE PATIENT"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"USER NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"NAME1"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        adm.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">admActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"SEARCH"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"AGE1"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"DISEASE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PHONE_NUMBER"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"GUARDOAN"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel9.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UNAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel10.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PWD"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        name.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"\\\\"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            jButton2.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"jPasswordField1"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                                 </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">admActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                   </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k5">String</span><span class="enlighter-text"> userName = adm.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from patient where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">,userName</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">                adm.</span><span class="enlighter-m3">setEditable</span><span class="enlighter-g1">(</span><span class="enlighter-e0">false</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               </span></div></div><div class=""><div><span class="enlighter-text">                name.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                age.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                disease.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                guardian.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                phone_number.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                uname.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               </span><span class="enlighter-c0"> //not exists</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Invalid User Name !!"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text">       </span><span class="enlighter-c0"> // TODO add your handling code here:</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton2ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text"> </span><span class="enlighter-k1">try</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">             </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"update patient set name1 = ?, age1 = ?,disease = ?,phone_number = ?,guardian = ?,pwd = ? where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, age.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, disease.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, phone_number.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-text">,guardian.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-text">, uname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-text">,pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">x</span><span class="enlighter-g1">&gt;</span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"patient Details updated"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Updatestaff as = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatestaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                as.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatepatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> adm;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> age;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> disease;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> guardian;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel10;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel9;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> phone_number;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> uname;</span></div></div><div class=""><div><span class="enlighter-text">                     </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Updatestaff.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-c1">/**</span></div></div><div class=""><div><span class="enlighter-c1"> *</span></div></div><div class=""><div><span class="enlighter-c1"> * @author lenovo</span></div></div><div class=""><div><span class="enlighter-c1"> */</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Updatestaff </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatestaff</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                            </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        adm = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel5 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel6 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel7 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel8 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel9 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        name = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        age = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        qualification = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        address = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        phone = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        uname = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"USER NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"SEARCH"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"CLEAR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"NAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"AGE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel5.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"QUALIFICATION"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel6.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"ADDRESS"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel7.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PHONE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel8.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UNAME"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel9.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PWD"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        phone.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">phoneActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        pwd.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">pwdActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"UPDATE"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton3.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                          </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">phoneActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                      </span></div></div><div class=""><div><span class="enlighter-text">       </span><span class="enlighter-c0"> // TODO add your handling code here:</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">pwdActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text">       </span><span class="enlighter-c0"> // TODO add your handling code here:</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                   </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text"> </span><span class="enlighter-k5">String</span><span class="enlighter-text"> userName = adm.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from staff where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, userName</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               </span><span class="enlighter-c0"> //exist</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                adm.</span><span class="enlighter-m3">setEditable</span><span class="enlighter-g1">(</span><span class="enlighter-e0">false</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               </span></div></div><div class=""><div><span class="enlighter-text">                name.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                age.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                qualification.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                address.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                phone.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                uname.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                  pwd.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               </span><span class="enlighter-c0"> //not exists</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Invalid User Name !!"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">              </span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">                              </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton3ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">     </span><span class="enlighter-k1">try</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">             </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"update staff set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, name.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, age.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">              ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-text">, qualification.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-text">, address.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">               ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-text">,phone.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">             </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-text">, uname.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">            ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-text">,pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">int</span><span class="enlighter-text"> x = ps.</span><span class="enlighter-m3">executeUpdate</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">x</span><span class="enlighter-g1">&gt;</span><span class="enlighter-n1">0</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Staff Details updated"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Updatestaff as = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatestaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                as.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">     </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Updatestaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> address;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> adm;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> age;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel5;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel6;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel7;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel8;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel9;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> name;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> phone;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> qualification;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> uname;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Viewdoctor_1.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.table.DefaultTableModel</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Viewdoctor_1 </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewdoctor_1</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jTable1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">DISPOSE_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">addWindowListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowAdapter</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">windowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jTable1.</span><span class="enlighter-m3">setModel</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">table</span><span class="enlighter-text">.</span><span class="enlighter-m3">DefaultTableModel</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> Object </span><span class="enlighter-g1">[][]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">String</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-s0">"name"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"age"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"qualification"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"address"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"phone"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"uname"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"pwd"</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">boolean</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> canEdit = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-m0">isCellEditable</span><span class="enlighter-g1">(</span><span class="enlighter-k5">int</span><span class="enlighter-text"> rowIndex, </span><span class="enlighter-k5">int</span><span class="enlighter-text"> columnIndex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k0">return</span><span class="enlighter-text"> canEdit </span><span class="enlighter-g1">[</span><span class="enlighter-text">columnIndex</span><span class="enlighter-g1">]</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1.</span><span class="enlighter-m3">setViewportView</span><span class="enlighter-g1">(</span><span class="enlighter-text">jTable1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                           </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text">         DefaultTableModel model = </span><span class="enlighter-g1">(</span><span class="enlighter-text">DefaultTableModel</span><span class="enlighter-g1">)</span><span class="enlighter-text">jTable1.</span><span class="enlighter-m3">getModel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from doctor"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">while</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> name = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text">  age = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> qualification = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> address = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> phone = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> uname = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> pwd = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Object ob</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> = </span><span class="enlighter-g1">{</span><span class="enlighter-text">name, age, qualification, address, phone,uname,pwd</span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                model.</span><span class="enlighter-m3">addRow</span><span class="enlighter-g1">(</span><span class="enlighter-text">ob</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewdoctor_1</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-text"> jScrollPane1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-text"> jTable1;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">Viewpatient.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.table.DefaultTableModel</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Viewpatient </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span><span class="enlighter-c0"> // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          </span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jTable1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">DISPOSE_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">addWindowListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowAdapter</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">windowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jTable1.</span><span class="enlighter-m3">setModel</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">table</span><span class="enlighter-text">.</span><span class="enlighter-m3">DefaultTableModel</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> Object </span><span class="enlighter-g1">[][]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">String</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-s0">"name"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"age"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"disease"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"phone_number"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"guardian"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"uname"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"pwd"</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">boolean</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> canEdit = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-m0">isCellEditable</span><span class="enlighter-g1">(</span><span class="enlighter-k5">int</span><span class="enlighter-text"> rowIndex, </span><span class="enlighter-k5">int</span><span class="enlighter-text"> columnIndex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k0">return</span><span class="enlighter-text"> canEdit </span><span class="enlighter-g1">[</span><span class="enlighter-text">columnIndex</span><span class="enlighter-g1">]</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1.</span><span class="enlighter-m3">setViewportView</span><span class="enlighter-g1">(</span><span class="enlighter-text">jTable1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text">         DefaultTableModel model = </span><span class="enlighter-g1">(</span><span class="enlighter-text">DefaultTableModel</span><span class="enlighter-g1">)</span><span class="enlighter-text">jTable1.</span><span class="enlighter-m3">getModel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from patient"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">while</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> name1 = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text">  age1 = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> disease = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> phone_number = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> guardian = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> uname = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> pwd = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Object ob</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> = </span><span class="enlighter-g1">{</span><span class="enlighter-text">name1, age1, disease, phone_number, guardian,uname,pwd</span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                model.</span><span class="enlighter-m3">addRow</span><span class="enlighter-g1">(</span><span class="enlighter-text">ob</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewpatient</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                        </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-text"> jScrollPane1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-text"> jTable1;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewstaff.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.table.DefaultTableModel</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> Viewstaff </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jTable1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">DISPOSE_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">addWindowListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowAdapter</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">windowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jTable1.</span><span class="enlighter-m3">setModel</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">table</span><span class="enlighter-text">.</span><span class="enlighter-m3">DefaultTableModel</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> Object </span><span class="enlighter-g1">[][]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">String</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-s0">"name"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"age"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"qualification"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"address"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"phone"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"uname"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"pwd"</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">boolean</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> canEdit = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text">, </span><span class="enlighter-e0">true</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-m0">isCellEditable</span><span class="enlighter-g1">(</span><span class="enlighter-k5">int</span><span class="enlighter-text"> rowIndex, </span><span class="enlighter-k5">int</span><span class="enlighter-text"> columnIndex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k0">return</span><span class="enlighter-text"> canEdit </span><span class="enlighter-g1">[</span><span class="enlighter-text">columnIndex</span><span class="enlighter-g1">]</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1.</span><span class="enlighter-m3">setViewportView</span><span class="enlighter-g1">(</span><span class="enlighter-text">jTable1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text">         DefaultTableModel model = </span><span class="enlighter-g1">(</span><span class="enlighter-text">DefaultTableModel</span><span class="enlighter-g1">)</span><span class="enlighter-text">jTable1.</span><span class="enlighter-m3">getModel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from doctor"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">while</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> name = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text">  age = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> qualification = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> address = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> phone = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">5</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> uname = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">6</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> pwd = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">7</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                Object ob</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> = </span><span class="enlighter-g1">{</span><span class="enlighter-text">name, age, qualification, address, phone,uname,pwd</span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                model.</span><span class="enlighter-m3">addRow</span><span class="enlighter-g1">(</span><span class="enlighter-text">ob</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">      </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Viewstaff</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-text"> jScrollPane1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-text"> jTable1;</span></div></div><div class=""><div><span class="enlighter-text">                  </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">hmsproject.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JFrame</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.JOptionPane</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> hmsproject </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                          </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">ButtonGroup</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel3 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        staffr = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        doctorr = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton2 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        namer = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        pwd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jLabel4 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">EXIT_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"LOGIN FORM"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"NAME "</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel3.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"PASSWORD"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">staffr</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        staffr.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        buttonGroup1.</span><span class="enlighter-m3">add</span><span class="enlighter-g1">(</span><span class="enlighter-text">doctorr</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        doctorr.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"LOGIN"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jButton1.</span><span class="enlighter-m3">addActionListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionListener</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">actionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jButton2.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"CLEAR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jLabel4.</span><span class="enlighter-m3">setText</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"LOGIN AS"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                           </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">jButton1ActionPerformed</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">ActionEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                         </span></div></div><div class=""><div><span class="enlighter-text">         </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con=Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps=</span><span class="enlighter-e1">null</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">staffr.</span><span class="enlighter-m3">isSelected</span><span class="enlighter-g1">()){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                ps=con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from staff where uname=? and pwd=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">,namer.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                 ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">,pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ResultSet rs=ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">()){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                      JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Welcome STAFF"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    Staffdashboard sd = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Staffdashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    sd.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span><span class="enlighter-c0"> //to open new frame ad</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                   </span><span class="enlighter-c0"> //invalid admin</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">, </span><span class="enlighter-s0">"Invalid Uname or Password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hmsproject hms = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hms.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;       </span><span class="enlighter-c0"> //to open new frame ad</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;            </span><span class="enlighter-c0"> //to close current frame</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">              </span><span class="enlighter-k1">else</span><span class="enlighter-text"> </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">doctorr.</span><span class="enlighter-m3">isSelected</span><span class="enlighter-g1">())</span><span class="enlighter-text">     </span><span class="enlighter-c0"> //radio button selection</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">               </span><span class="enlighter-c0"> //teacher login</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from doctor where uname=? and pwd=?"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-text">, namer.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ps.</span><span class="enlighter-m3">setString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-text">, pwd.</span><span class="enlighter-m3">getText</span><span class="enlighter-g1">())</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                ResultSet rs=ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">if</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text">  </span><span class="enlighter-c0"> // valid teacher</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">,</span><span class="enlighter-s0">"welocome DOCTOR"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    Doctordashboard td =</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Doctordashboard</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    td.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k1">else</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">{</span><span class="enlighter-text"> </span><span class="enlighter-c0"> // Invalid teacher</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                    JOptionPane.</span><span class="enlighter-m3">showMessageDialog</span><span class="enlighter-g1">(</span><span class="enlighter-e1">null</span><span class="enlighter-text">,</span><span class="enlighter-s0">"Invalid username and password"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hmsproject hms = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    hms.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span><span class="enlighter-k9">this</span><span class="enlighter-text">.</span><span class="enlighter-m3">dispose</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                    </span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text">  </span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span></div></div><div class=""><div><span class="enlighter-text"> </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                        </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">hmsproject</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">ButtonGroup</span><span class="enlighter-text"> buttonGroup1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-text"> doctorr;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JButton</span><span class="enlighter-text"> jButton2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel2;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel3;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JLabel</span><span class="enlighter-text"> jLabel4;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTextField</span><span class="enlighter-text"> namer;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JPasswordField</span><span class="enlighter-text"> pwd;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JRadioButton</span><span class="enlighter-text"> staffr;</span></div></div><div class=""><div><span class="enlighter-text">                  </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewtest.</span><span class="enlighter-m3">java</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">package</span><span class="enlighter-k10"> jan1</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.Connection</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.PreparedStatement</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> java.sql.ResultSet</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">import</span><span class="enlighter-k10"> javax.swing.table.DefaultTableModel</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">class</span><span class="enlighter-text"> viewtest </span><span class="enlighter-k0">extends</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JFrame</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-m0">viewtest</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">   </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k11">@SuppressWarnings</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"unchecked"</span><span class="enlighter-g1">)</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                             </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">initComponents</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jTable1 = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">setDefaultCloseOperation</span><span class="enlighter-g1">(</span><span class="enlighter-text">javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowConstants</span><span class="enlighter-text">.</span><span class="enlighter-m3">DISPOSE_ON_CLOSE</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-m0">addWindowListener</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowAdapter</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">windowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">evt</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        jTable1.</span><span class="enlighter-m3">setModel</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">table</span><span class="enlighter-text">.</span><span class="enlighter-m3">DefaultTableModel</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> Object </span><span class="enlighter-g1">[][]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">String</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-s0">"NAME"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"FEES"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"DESC"</span><span class="enlighter-text">, </span><span class="enlighter-s0">"DOCT"</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k5">boolean</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> canEdit = </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-g1">[]</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text">, </span><span class="enlighter-e0">false</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">boolean</span><span class="enlighter-text"> </span><span class="enlighter-m0">isCellEditable</span><span class="enlighter-g1">(</span><span class="enlighter-k5">int</span><span class="enlighter-text"> rowIndex, </span><span class="enlighter-k5">int</span><span class="enlighter-text"> columnIndex</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k0">return</span><span class="enlighter-text"> canEdit </span><span class="enlighter-g1">[</span><span class="enlighter-text">columnIndex</span><span class="enlighter-g1">]</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        jScrollPane1.</span><span class="enlighter-m3">setViewportView</span><span class="enlighter-g1">(</span><span class="enlighter-text">jTable1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">       </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">formWindowActivated</span><span class="enlighter-g1">(</span><span class="enlighter-text">java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">event</span><span class="enlighter-text">.</span><span class="enlighter-m3">WindowEvent</span><span class="enlighter-text"> evt</span><span class="enlighter-g1">)</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text">                                     </span></div></div><div class=""><div><span class="enlighter-text">          DefaultTableModel model = </span><span class="enlighter-g1">(</span><span class="enlighter-text">DefaultTableModel</span><span class="enlighter-g1">)</span><span class="enlighter-text">jTable1.</span><span class="enlighter-m3">getModel</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-k1">try</span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            Connection con = Connectiondb.</span><span class="enlighter-m3">getConnection</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            PreparedStatement ps = con.</span><span class="enlighter-m3">prepareStatement</span><span class="enlighter-g1">(</span><span class="enlighter-s0">"select * from teacher"</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            ResultSet rs = ps.</span><span class="enlighter-m3">executeQuery</span><span class="enlighter-g1">()</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k1">while</span><span class="enlighter-g1">(</span><span class="enlighter-text">rs.</span><span class="enlighter-m3">next</span><span class="enlighter-g1">())</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> name = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">1</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> fees = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">2</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> desc= rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">3</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k5">String</span><span class="enlighter-text"> doct = rs.</span><span class="enlighter-m3">getString</span><span class="enlighter-g1">(</span><span class="enlighter-n1">4</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span></div></div><div class=""><div><span class="enlighter-text">                </span></div></div><div class=""><div><span class="enlighter-text">                Object ob</span><span class="enlighter-g1">[]</span><span class="enlighter-text"> = </span><span class="enlighter-g1">{</span><span class="enlighter-text">name, fees, desc,doct </span><span class="enlighter-g1">}</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">                model.</span><span class="enlighter-m3">addRow</span><span class="enlighter-g1">(</span><span class="enlighter-text">ob</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-k1">catch</span><span class="enlighter-g1">(</span><span class="enlighter-text">Exception e</span><span class="enlighter-g1">){</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            System.</span><span class="enlighter-m3">out</span><span class="enlighter-text">.</span><span class="enlighter-m3">println</span><span class="enlighter-g1">(</span><span class="enlighter-text">e</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text">                                    </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k0">static</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">main</span><span class="enlighter-g1">(</span><span class="enlighter-k5">String</span><span class="enlighter-text"> args</span><span class="enlighter-g1">[])</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">      </span></div></div><div class=""><div><span class="enlighter-text">        java.</span><span class="enlighter-m3">awt</span><span class="enlighter-text">.</span><span class="enlighter-m3">EventQueue</span><span class="enlighter-text">.</span><span class="enlighter-m3">invokeLater</span><span class="enlighter-g1">(</span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">Runnable</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-k0">public</span><span class="enlighter-text"> </span><span class="enlighter-k5">void</span><span class="enlighter-text"> </span><span class="enlighter-m0">run</span><span class="enlighter-g1">()</span><span class="enlighter-text"> </span><span class="enlighter-g1">{</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                </span><span class="enlighter-k3">new</span><span class="enlighter-text"> </span><span class="enlighter-m0">viewtest</span><span class="enlighter-g1">()</span><span class="enlighter-text">.</span><span class="enlighter-m3">setVisible</span><span class="enlighter-g1">(</span><span class="enlighter-e0">true</span><span class="enlighter-g1">)</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">            </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">        </span><span class="enlighter-g1">})</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">                     </span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JScrollPane</span><span class="enlighter-text"> jScrollPane1;</span></div></div><div class=""><div><span class="enlighter-text">    </span><span class="enlighter-k0">private</span><span class="enlighter-text"> javax.</span><span class="enlighter-m3">swing</span><span class="enlighter-text">.</span><span class="enlighter-m3">JTable</span><span class="enlighter-text"> jTable1;</span></div></div><div class=""><div><span class="enlighter-text">                      </span></div></div><div class=""><div><span class="enlighter-text"></span><span class="enlighter-g1">}</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">----------------------------------------------------------------------------------------------------------------------------------------------------------------</span></div></div><div class=""><div><span class="enlighter-text">queries </span><span class="enlighter-k1">for</span><span class="enlighter-text"> creating tables</span></div></div><div class=""><div><span class="enlighter-text">create database hms</span><span class="enlighter-c0">;// for creating database</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">use hms;</span></div></div><div class=""><div><span class="enlighter-text">create table </span><span class="enlighter-m0">staff</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">name </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">age </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">qualification </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">address </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">phone </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">uname </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">pwd </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">create table </span><span class="enlighter-m0">doctor</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">name </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">age </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">qualification </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">address </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">phone </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">10</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">uname </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">pwd </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text">  </span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">create table </span><span class="enlighter-m0">patient</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">name1 </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">age1 </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">disease </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">phone_number </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">guardian </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">uname </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">pwd </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">create table </span><span class="enlighter-m0">appointment</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">name </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">dname </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">page </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">date </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div><div class=""><div><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">create table </span><span class="enlighter-m0">test</span><span class="enlighter-g1">(</span><span class="enlighter-text"></span></div></div><div class=""><div><span class="enlighter-text">name1 </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">fees </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">desc </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">)</span><span class="enlighter-text">,</span></div></div><div class=""><div><span class="enlighter-text">doct </span><span class="enlighter-m0">varchar</span><span class="enlighter-g1">(</span><span class="enlighter-n1">100</span><span class="enlighter-g1">))</span><span class="enlighter-text">;</span></div></div></div><div class="enlighter-raw">package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class hmsproject extends javax.swing.JFrame {
 public hmsproject() {
        initComponents();
    }
@SuppressWarnings("unchecked")
private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         
        try{
            Connection con=Connectiondb.getConnection();
            PreparedStatement ps=null;
            if(staffr.isSelected()){
                ps=con.prepareStatement("select * from staff where uname=? and pwd=?");
                ps.setString(1,namer.getText());
                 ps.setString(2,pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next()){
                      JOptionPane.showMessageDialog(null, "Welcome STAFF");
                    Staffdashboard sd = new Staffdashboard();
                    sd.setVisible(true);        //to open new frame ad
                    this.dispose();
                }
                else
                {
                    //invalid admin
                    JOptionPane.showMessageDialog(null, "Invalid Uname or Password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);        //to open new frame ad
                    this.dispose();             //to close current frame
                }
                    
                
            }
              else if(doctorr.isSelected())    
            {
                
                ps = con.prepareStatement
                    ("select * from doctor where uname=? and pwd=?");
                ps.setString(1, namer.getText());
                ps.setString(2, pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next())
                {   
                    JOptionPane.showMessageDialog(null,"welocome DOCTOR");
                    Doctordashboard td =new Doctordashboard();
                    td.setVisible(true);
                    this.dispose();
                    
                }
                else
                {  
                    JOptionPane.showMessageDialog(null,"Invalid username and password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);
                    this.dispose();
                    
                }
                
                
            }
   
        }  catch(Exception e)
        {
            System.out.println(e);
        }
 public static void main(String args[]) {
java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new hmsproject().setVisible(true);
            }
        });
    }
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton doctorr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField namer;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JRadioButton staffr;
                       
}
    ------------------------------------------------------------------------------------------------------------------------------    
Addpatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class Addpatient extends javax.swing.JFrame {
public Addpatient() {
        initComponents();
    }

   
    // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name1 = new javax.swing.JTextField();
        age1 = new javax.swing.JTextField();
        disease = new javax.swing.JTextField();
        phone_number = new javax.swing.JTextField();
        guardian = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW PATIENT");

        jLabel2.setText("NAME ");

        jLabel3.setText("AGE");

        jLabel4.setText("DISEASE");

        jLabel5.setText("PHONE NUMBER");

        jLabel6.setText("GUARDIAN");

        age1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                age1ActionPerformed(evt);
            }
        });

        disease.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diseaseActionPerformed(evt);
            }
        });

        guardian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianActionPerformed(evt);
            }
        });

        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("uname");

        jLabel8.setText("password");

        


    private void age1ActionPerformed(java.awt.event.ActionEvent evt) {                                     
        
    }                                    

    private void guardianActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
    }                                        

    private void diseaseActionPerformed(java.awt.event.ActionEvent evt) {                                        
        
    }                                       

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         try {
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into patient(name1,age1,disease,phone_number,guardian,uname,pwd) values(?,?,?,?,?,?,?)");
            ps.setString(1, name1.getText());
            ps.setString(2, age1.getText());
            ps.setString(3, disease.getText());
            ps.setString(4, phone_number.getText());
            ps.setString(5, guardian.getText());
            ps.setString(6, uname.getText());
            ps.setString(7, pwd.getText());
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "Patient Added");
                Addpatient ap = new Addpatient();
                ap.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
name1.setText(" ");
age1.setText(" ");
disease.setText(" ");
phone_number.setText(" ");
guardian.setText(" ");

    }                                        

  
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch Exception ex) ({
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addpatient().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField age1;
    private javax.swing.JTextField disease;
    private javax.swing.JTextField guardian;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField name1;
    private javax.swing.JTextField phone_number;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField uname;
                       
}
--------------------------------------------------------------------------------------------------------------------
Addstaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
public class Addstaff extends javax.swing.JFrame {

    public Addstaff() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    &gt;                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pwd = new javax.swing.JPasswordField();
        uname = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW STAFF");

        jLabel2.setText("NAME");

        jLabel3.setText("AGE");

        jLabel4.setText("QUALIFICATION");

        jLabel5.setText("ADDRESS");

        jLabel6.setText("PHONE");

        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("uname ");

        jLabel8.setText("password");

        pwd.setText("jPasswordField1");

   &gt;                        

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into staff(name,age,qualification,address,phone,uname,pwd) values(?,?,?,?,?,?,?)");
            ps.setString(1, name.getText());
            ps.setString(2, age.getText());
            ps.setString(3, qualification.getText());
            ps.setString(4, address.getText());
            ps.setString(5, phone.getText());
            ps.setString(6, uname.getText());
            ps.setString(7, pwd.getText());
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "Staff Added");
                Addstaff as = new Addstaff();
                as.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
name.setText(" ");
age.setText(" ");
qualification.setText(" ");
address.setText(" ");
phone.setText(" ");
uname.setText(" ");
pwd.setText(" ");
    }                                        

    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addstaff().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField address;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                      
}
----------------------------------------------------------------------------------------------------------------------------------------------------------
Addtest.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
public class Addtest extends javax.swing.JFrame {

    public Addtest() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    &gt;                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        DOOCTOR = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        name1 = new javax.swing.JTextField();
        fees = new javax.swing.JTextField();
        desc1 = new javax.swing.JTextField();
        doct = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW TEST");

        jLabel2.setText("TEST NAME");

        jLabel3.setText("TEST FEES");

        jLabel4.setText("DESCRIPTION");

        DOOCTOR.setText("DOCTOR");

        jButton1.setText("SAVE");
        buttonGroup1.add(jButton1);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        buttonGroup1.add(jButton2);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        desc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desc1ActionPerformed(evt);
            }
        });

                          

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
          try {
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into test(name1,fees,desc1,doct) values(?,?,?,?)");
            ps.setString(1, name1.getText());
            ps.setString(2, fees.getText());
            ps.setString(3, desc1.getText());
            ps.setString(4, doct.getText());
            
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "TEST Added");
                Adddoctor ad = new Adddoctor();
                ad.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
      name1.setText(" ");
      fees.setText(" ");
      desc1.setText(" ");
      doct.setText(" ");
    }                                        

    private void desc1ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        
    }                                     

    
    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addtest().setVisible(true);
            }
        });
    }

                         
    private javax.swing.JLabel DOOCTOR;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField desc1;
    private javax.swing.JTextField doct;
    private javax.swing.JTextField fees;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField name1;
                       
}
---------------------------------------------------------------------------------------------------------------------------------------------------------
Appointment.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;


public class Appointment extends javax.swing.JFrame {

  
    public Appointment() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        dname = new javax.swing.JTextField();
        page = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("appointment");

        jLabel2.setText("patient's name");

        jLabel3.setText("doctor's name");

        jLabel4.setText("patient's age");

        jLabel6.setText(" will text you the timings of appointment as soon as possible ");

        jButton1.setText("submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

                              

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into appointment(name,dname,page,date) values(?,?,?,?)");
            ps.setString(1, name.getText());
            ps.setString(2, dname.getText());
            ps.setString(3, page.getText());
            
            Date d = new Date();
              SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
              String dd = sd.format(d);
              ps.setString(4, dd);
               int x = ps.executeUpdate();
              if(x&gt;0)    
              {
                  JOptionPane.showMessageDialog(null, "APPOINTMENT PROCESSED");
                  Appointment ad = new Appointment();
                  ad.setVisible(true);
                  this.dispose();
              }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }                                        

  
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Appointment().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField dname;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField name;
    private javax.swing.JTextField page;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bill.java
package jan1;

public class Bill extends javax.swing.JFrame {

 
    public Bill() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        a = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        b = new javax.swing.JTextField();
        c = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        g = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Bill of patient");

        jLabel2.setText("ENTER NUMBER OF DAYS PATIENT WAS ADMITTED");

        jLabel3.setText("ENTER  TOTAL COST OF TESTS");

        jLabel4.setText("ENTER TOTAL FEES OF DOCTOR");

        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });

        jButton1.setText("GENERATE BILL");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

     

                        

    private void bActionPerformed(java.awt.event.ActionEvent evt) {                                  
       
    }                                 

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
int d=Integer.parseInt(a.getText());  
int e=Integer.parseInt(b.getText()); 
int f=Integer.parseInt(c.getText());
int m=d*5000+e+f;
g.setText(m+" ");
// TODO add your handling code here:
    }                                        

    public static void main(String args[]) {
      
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bill().setVisible(true);
            }
        });
    }

                      
    private javax.swing.JTextField a;
    private javax.swing.JTextField b;
    private javax.swing.JTextField c;
    private javax.swing.JTextField g;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
                    
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Connection.java
package jan1;
import java.sql.DriverManager;
import java.sql.Connection;


public class Connectiondb {
    public static Connection getConnection(){
        Connection con=null;
        try{
            Class.forName ("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hms","id","password");
        }
        catch(Exception e){
            System.out.println(e);
        }
        return con;
    }
    
}
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Doctordashboard.java
package jan1;

public class Doctordashboard extends javax.swing.JFrame {

  /
    public Doctordashboard() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("WELCOME DOCTOR");

        jMenu1.setText("File");

        jMenuItem1.setText("viewtest");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Addtest");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("patients");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("add patient");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setText("update patient");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setText("jMenuItem6");
        jMenu1.add(jMenuItem6);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

                        

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new viewtest().setVisible(true);        :
    }                                          

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addpatient().setVisible(true);      
    }                                          

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addtest().setVisible(true);        
    }                                          

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewpatient().setVisible(true);        
    }                                          

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Updatepatient().setVisible(true);        
    }                                          

  
    public static void main(String args[]) {
    
       

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doctordashboard().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

Staffdashboard.java
package jan1;

public class Staffdashboard extends javax.swing.JFrame {

   
    public Staffdashboard() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("welcome staff");

        jMenu1.setText("File");

        jMenuItem1.setText("Add doctor");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Add staff");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Add patient");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("Add test");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setText("appointmemts");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setText("view doctor");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        jMenuItem7.setText("Update doctor");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem7);

        jMenuItem8.setText("BILL");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem8);

        jMenuItem9.setText("VIEW DOCTOR");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem9);

        jMenuItem10.setText("VIEW PATIENT");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem10);

        jMenuItem11.setText("VIEW STAFF");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem11);

        jMenuItem12.setText("UPDATE PATIENT");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem12);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

  
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Adddoctor().setVisible(true);        
    }                                          

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addstaff().setVisible(true);

    }                                          

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addpatient().setVisible(true);       
    }                                          

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addtest().setVisible(true);        
    }                                          

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Appointment().setVisible(true);       
    }                                          

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewdoctor_1().setVisible(true);        
    }                                          

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Updatedoctor().setVisible(true);

    }                                          

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Bill().setVisible(true);       
    }                                          

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewdoctor_1().setVisible(true);        
    }                                          

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Viewpatient().setVisible(true);       
    }                                           

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Viewstaff().setVisible(true);

    }                                           

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Updatepatient().setVisible(true);        
    }                                           

   
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Staffdashboard().setVisible(true);
            }
        });
    }
                    
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatedoctor.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Updatedoctor extends javax.swing.JFrame {


    public Updatedoctor() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE DOCTOR");

        jLabel2.setText("USER NAME");

        jButton1.setText("search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("clear");

        jLabel3.setText("name");

        jLabel4.setText("age");

        jLabel5.setText("qualification");

        jLabel6.setText("address");

        jLabel7.setText("phone");

        jLabel8.setText("uname");

        jLabel9.setText("pwd");

        jButton3.setText("submit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

                         

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from doctor where uname=?");
            ps.setString(1,userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
              
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                qualification.setText(rs.getString(3));
                address.setText(rs.getString(4));
                phone.setText(rs.getString(5));
                adm.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
             
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }
              
        
                              
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
     uname.setText(" ") ;       
    }                                        

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
       try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update doctor set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, qualification.getText());
                ps.setString(4, address.getText());
               ps.setString(5,phone.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "DOCTOR Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    
    }                                        

    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatedoctor().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField address;
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                    
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatepatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Updatepatient extends javax.swing.JFrame {

   
    public Updatepatient() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
                         
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        disease = new javax.swing.JTextField();
        phone_number = new javax.swing.JTextField();
        guardian = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        pwd = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE PATIENT");

        jLabel2.setText("USER NAME");

        jLabel3.setText("NAME1");

        adm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admActionPerformed(evt);
            }
        });

        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setText("AGE1");

        jLabel6.setText("DISEASE");

        jLabel7.setText("PHONE_NUMBER");

        jLabel8.setText("GUARDOAN");

        jLabel9.setText("UNAME");

        jLabel10.setText("PWD");

        name.setText("\\\\");

            jButton2.setText("UPDATE");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            pwd.setText("jPasswordField1");

                                 

    private void admActionPerformed(java.awt.event.ActionEvent evt) {                                    
        
    }                                   

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from patient where uname=?");
            ps.setString(1,userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                disease.setText(rs.getString(3));
                guardian.setText(rs.getString(4));
                phone_number.setText(rs.getString(5));
                uname.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
                //not exists
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }        // TODO add your handling code here:
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
 try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update patient set name1 = ?, age1 = ?,disease = ?,phone_number = ?,guardian = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, disease.getText());
                ps.setString(4, phone_number.getText());
               ps.setString(5,guardian.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "patient Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }        
    }                                        

   
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatepatient().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JTextField disease;
    private javax.swing.JTextField guardian;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone_number;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JTextField uname;
                     
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatestaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lenovo
 */
public class Updatestaff extends javax.swing.JFrame {

  
    public Updatestaff() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE STAFF");

        jLabel2.setText("USER NAME");

        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");

        jLabel3.setText("NAME");

        jLabel4.setText("AGE");

        jLabel5.setText("QUALIFICATION");

        jLabel6.setText("ADDRESS");

        jLabel7.setText("PHONE");

        jLabel8.setText("UNAME");

        jLabel9.setText("PWD");

        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });

        pwd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pwdActionPerformed(evt);
            }
        });

        jButton3.setText("UPDATE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

                          

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {                                      
        // TODO add your handling code here:
    }                                     

    private void pwdActionPerformed(java.awt.event.ActionEvent evt) {                                    
        // TODO add your handling code here:
    }                                   

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
 String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from staff where uname=?");
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                //exist
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                qualification.setText(rs.getString(3));
                address.setText(rs.getString(4));
                phone.setText(rs.getString(5));
                uname.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
                //not exists
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }
              
        
                              
    }                                        

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
     try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update staff set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, qualification.getText());
                ps.setString(4, address.getText());
               ps.setString(5,phone.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "Staff Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }                                        

   
    public static void main(String args[]) {
    
   
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatestaff().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField address;
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                      
}
-------------------------------------------------------------------------------------------------------------
Viewdoctor_1.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;



public class Viewdoctor_1 extends javax.swing.JFrame {

    public Viewdoctor_1() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "qualification", "address", "phone", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
        });
        jScrollPane1.setViewportView(jTable1);

                           

    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from doctor");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String  age = rs.getString(2);
                String qualification = rs.getString(3);
                String address = rs.getString(4);
                String phone = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name, age, qualification, address, phone,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

  
    public static void main(String args[]) {
    

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewdoctor_1().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Viewpatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;



public class Viewpatient extends javax.swing.JFrame {

    
    public Viewpatient() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "disease", "phone_number", "guardian", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

    
    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from patient");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name1 = rs.getString(1);
                String  age1 = rs.getString(2);
                String disease = rs.getString(3);
                String phone_number = rs.getString(4);
                String guardian = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name1, age1, disease, phone_number, guardian,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewpatient().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewstaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class Viewstaff extends javax.swing.JFrame {

    public Viewstaff() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "qualification", "address", "phone", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from doctor");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String  age = rs.getString(2);
                String qualification = rs.getString(3);
                String address = rs.getString(4);
                String phone = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name, age, qualification, address, phone,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewstaff().setVisible(true);
            }
        });
    }

                      
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                  
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
hmsproject.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class hmsproject extends javax.swing.JFrame {

    
    public hmsproject() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        staffr = new javax.swing.JRadioButton();
        doctorr = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        namer = new javax.swing.JTextField();
        pwd = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("LOGIN FORM");

        jLabel2.setText("NAME ");

        jLabel3.setText("PASSWORD");

        buttonGroup1.add(staffr);
        staffr.setText("STAFF");

        buttonGroup1.add(doctorr);
        doctorr.setText("DOCTOR");

        jButton1.setText("LOGIN");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");

        jLabel4.setText("LOGIN AS");

                           

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         
        try{
            Connection con=Connectiondb.getConnection();
            PreparedStatement ps=null;
            if(staffr.isSelected()){
                ps=con.prepareStatement("select * from staff where uname=? and pwd=?");
                ps.setString(1,namer.getText());
                 ps.setString(2,pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next()){
                      JOptionPane.showMessageDialog(null, "Welcome STAFF");
                    Staffdashboard sd = new Staffdashboard();
                    sd.setVisible(true);        //to open new frame ad
                    this.dispose();
                }
                else
                {
                    //invalid admin
                    JOptionPane.showMessageDialog(null, "Invalid Uname or Password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);        //to open new frame ad
                    this.dispose();             //to close current frame
                }
                    
                
            }
              else if(doctorr.isSelected())      //radio button selection
            {
                //teacher login
                ps = con.prepareStatement
                    ("select * from doctor where uname=? and pwd=?");
                ps.setString(1, namer.getText());
                ps.setString(2, pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next())
                {   // valid teacher
                    JOptionPane.showMessageDialog(null,"welocome DOCTOR");
                    Doctordashboard td =new Doctordashboard();
                    td.setVisible(true);
                    this.dispose();
                    
                }
                else
                {  // Invalid teacher
                    JOptionPane.showMessageDialog(null,"Invalid username and password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);
                    this.dispose();
                    
                }
                
                
            }
   
        }  catch(Exception e)
        {
            System.out.println(e);
        }
        
 
    }                                        

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new hmsproject().setVisible(true);
            }
        });
    }

                       
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton doctorr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField namer;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JRadioButton staffr;
                  
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewtest.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class viewtest extends javax.swing.JFrame {

   
    public viewtest() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "FEES", "DESC", "DOCT"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

       
    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
          DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from teacher");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String fees = rs.getString(2);
                String desc= rs.getString(3);
                String doct = rs.getString(4);
            
                
                Object ob[] = {name, fees, desc,doct };
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    


    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewtest().setVisible(true);
            }
        });
    }
                     
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
----------------------------------------------------------------------------------------------------------------------------------------------------------------
queries for creating tables
create database hms;// for creating database
use hms;
create table staff(
name varchar(100),
age varchar(100),
qualification varchar(100),
address varchar(100),
phone varchar(100),
uname varchar(100),
pwd varchar(100));

create table doctor(
name varchar(100),
age varchar(100),
qualification varchar(100),
address varchar(100),
phone varchar(10),
uname varchar(100),
pwd varchar(100));
  

create table patient(
name1 varchar(100),
age1 varchar(100),
disease varchar(100),
phone_number varchar(100),
guardian varchar(100),
uname varchar(100),
pwd varchar(100));

create table appointment(
name varchar(100),
dname varchar(100),
page varchar(100),
date varchar(100));

create table test(
name1 varchar(100),
fees varchar(100),
desc varchar(100),
doct varchar(100));</div><div class="enlighter-toolbar-bottom enlighter-toolbar"></div></div><pre class="EnlighterJSRAW enlighter-origin" data-enlighter-language="java">package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class hmsproject extends javax.swing.JFrame {
 public hmsproject() {
        initComponents();
    }
@SuppressWarnings("unchecked")
private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         
        try{
            Connection con=Connectiondb.getConnection();
            PreparedStatement ps=null;
            if(staffr.isSelected()){
                ps=con.prepareStatement("select * from staff where uname=? and pwd=?");
                ps.setString(1,namer.getText());
                 ps.setString(2,pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next()){
                      JOptionPane.showMessageDialog(null, "Welcome STAFF");
                    Staffdashboard sd = new Staffdashboard();
                    sd.setVisible(true);        //to open new frame ad
                    this.dispose();
                }
                else
                {
                    //invalid admin
                    JOptionPane.showMessageDialog(null, "Invalid Uname or Password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);        //to open new frame ad
                    this.dispose();             //to close current frame
                }
                    
                
            }
              else if(doctorr.isSelected())    
            {
                
                ps = con.prepareStatement
                    ("select * from doctor where uname=? and pwd=?");
                ps.setString(1, namer.getText());
                ps.setString(2, pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next())
                {   
                    JOptionPane.showMessageDialog(null,"welocome DOCTOR");
                    Doctordashboard td =new Doctordashboard();
                    td.setVisible(true);
                    this.dispose();
                    
                }
                else
                {  
                    JOptionPane.showMessageDialog(null,"Invalid username and password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);
                    this.dispose();
                    
                }
                
                
            }
   
        }  catch(Exception e)
        {
            System.out.println(e);
        }
 public static void main(String args[]) {
java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new hmsproject().setVisible(true);
            }
        });
    }
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton doctorr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField namer;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JRadioButton staffr;
                       
}
    ------------------------------------------------------------------------------------------------------------------------------    
Addpatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class Addpatient extends javax.swing.JFrame {
public Addpatient() {
        initComponents();
    }

   
    // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name1 = new javax.swing.JTextField();
        age1 = new javax.swing.JTextField();
        disease = new javax.swing.JTextField();
        phone_number = new javax.swing.JTextField();
        guardian = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW PATIENT");

        jLabel2.setText("NAME ");

        jLabel3.setText("AGE");

        jLabel4.setText("DISEASE");

        jLabel5.setText("PHONE NUMBER");

        jLabel6.setText("GUARDIAN");

        age1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                age1ActionPerformed(evt);
            }
        });

        disease.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diseaseActionPerformed(evt);
            }
        });

        guardian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianActionPerformed(evt);
            }
        });

        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("uname");

        jLabel8.setText("password");

        


    private void age1ActionPerformed(java.awt.event.ActionEvent evt) {                                     
        
    }                                    

    private void guardianActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
    }                                        

    private void diseaseActionPerformed(java.awt.event.ActionEvent evt) {                                        
        
    }                                       

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         try {
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into patient(name1,age1,disease,phone_number,guardian,uname,pwd) values(?,?,?,?,?,?,?)");
            ps.setString(1, name1.getText());
            ps.setString(2, age1.getText());
            ps.setString(3, disease.getText());
            ps.setString(4, phone_number.getText());
            ps.setString(5, guardian.getText());
            ps.setString(6, uname.getText());
            ps.setString(7, pwd.getText());
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "Patient Added");
                Addpatient ap = new Addpatient();
                ap.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
name1.setText(" ");
age1.setText(" ");
disease.setText(" ");
phone_number.setText(" ");
guardian.setText(" ");

    }                                        

  
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch Exception ex) ({
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Addpatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addpatient().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField age1;
    private javax.swing.JTextField disease;
    private javax.swing.JTextField guardian;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField name1;
    private javax.swing.JTextField phone_number;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField uname;
                       
}
--------------------------------------------------------------------------------------------------------------------
Addstaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
public class Addstaff extends javax.swing.JFrame {

    public Addstaff() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    &gt;                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pwd = new javax.swing.JPasswordField();
        uname = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW STAFF");

        jLabel2.setText("NAME");

        jLabel3.setText("AGE");

        jLabel4.setText("QUALIFICATION");

        jLabel5.setText("ADDRESS");

        jLabel6.setText("PHONE");

        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel7.setText("uname ");

        jLabel8.setText("password");

        pwd.setText("jPasswordField1");

   &gt;                        

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into staff(name,age,qualification,address,phone,uname,pwd) values(?,?,?,?,?,?,?)");
            ps.setString(1, name.getText());
            ps.setString(2, age.getText());
            ps.setString(3, qualification.getText());
            ps.setString(4, address.getText());
            ps.setString(5, phone.getText());
            ps.setString(6, uname.getText());
            ps.setString(7, pwd.getText());
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "Staff Added");
                Addstaff as = new Addstaff();
                as.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
name.setText(" ");
age.setText(" ");
qualification.setText(" ");
address.setText(" ");
phone.setText(" ");
uname.setText(" ");
pwd.setText(" ");
    }                                        

    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Addstaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addstaff().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField address;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                      
}
----------------------------------------------------------------------------------------------------------------------------------------------------------
Addtest.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
public class Addtest extends javax.swing.JFrame {

    public Addtest() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    &gt;                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        DOOCTOR = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        name1 = new javax.swing.JTextField();
        fees = new javax.swing.JTextField();
        desc1 = new javax.swing.JTextField();
        doct = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ADD NEW TEST");

        jLabel2.setText("TEST NAME");

        jLabel3.setText("TEST FEES");

        jLabel4.setText("DESCRIPTION");

        DOOCTOR.setText("DOCTOR");

        jButton1.setText("SAVE");
        buttonGroup1.add(jButton1);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");
        buttonGroup1.add(jButton2);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        desc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desc1ActionPerformed(evt);
            }
        });

                          

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
          try {
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into test(name1,fees,desc1,doct) values(?,?,?,?)");
            ps.setString(1, name1.getText());
            ps.setString(2, fees.getText());
            ps.setString(3, desc1.getText());
            ps.setString(4, doct.getText());
            
            int x = ps.executeUpdate();
            if (x &gt; 0) {
                JOptionPane.showMessageDialog(null, "TEST Added");
                Adddoctor ad = new Adddoctor();
                ad.setVisible(true);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
      name1.setText(" ");
      fees.setText(" ");
      desc1.setText(" ");
      doct.setText(" ");
    }                                        

    private void desc1ActionPerformed(java.awt.event.ActionEvent evt) {                                      
        
    }                                     

    
    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Addtest().setVisible(true);
            }
        });
    }

                         
    private javax.swing.JLabel DOOCTOR;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField desc1;
    private javax.swing.JTextField doct;
    private javax.swing.JTextField fees;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField name1;
                       
}
---------------------------------------------------------------------------------------------------------------------------------------------------------
Appointment.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;


public class Appointment extends javax.swing.JFrame {

  
    public Appointment() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        dname = new javax.swing.JTextField();
        page = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("appointment");

        jLabel2.setText("patient's name");

        jLabel3.setText("doctor's name");

        jLabel4.setText("patient's age");

        jLabel6.setText(" will text you the timings of appointment as soon as possible ");

        jButton1.setText("submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

                              

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into appointment(name,dname,page,date) values(?,?,?,?)");
            ps.setString(1, name.getText());
            ps.setString(2, dname.getText());
            ps.setString(3, page.getText());
            
            Date d = new Date();
              SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
              String dd = sd.format(d);
              ps.setString(4, dd);
               int x = ps.executeUpdate();
              if(x&gt;0)    
              {
                  JOptionPane.showMessageDialog(null, "APPOINTMENT PROCESSED");
                  Appointment ad = new Appointment();
                  ad.setVisible(true);
                  this.dispose();
              }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }                                        

  
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Appointment().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField dname;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField name;
    private javax.swing.JTextField page;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Bill.java
package jan1;

public class Bill extends javax.swing.JFrame {

 
    public Bill() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        a = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        b = new javax.swing.JTextField();
        c = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        g = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Bill of patient");

        jLabel2.setText("ENTER NUMBER OF DAYS PATIENT WAS ADMITTED");

        jLabel3.setText("ENTER  TOTAL COST OF TESTS");

        jLabel4.setText("ENTER TOTAL FEES OF DOCTOR");

        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });

        jButton1.setText("GENERATE BILL");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

     

                        

    private void bActionPerformed(java.awt.event.ActionEvent evt) {                                  
       
    }                                 

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
int d=Integer.parseInt(a.getText());  
int e=Integer.parseInt(b.getText()); 
int f=Integer.parseInt(c.getText());
int m=d*5000+e+f;
g.setText(m+" ");
// TODO add your handling code here:
    }                                        

    public static void main(String args[]) {
      
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bill().setVisible(true);
            }
        });
    }

                      
    private javax.swing.JTextField a;
    private javax.swing.JTextField b;
    private javax.swing.JTextField c;
    private javax.swing.JTextField g;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
                    
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Connection.java
package jan1;
import java.sql.DriverManager;
import java.sql.Connection;


public class Connectiondb {
    public static Connection getConnection(){
        Connection con=null;
        try{
            Class.forName ("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hms","id","password");
        }
        catch(Exception e){
            System.out.println(e);
        }
        return con;
    }
    
}
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Doctordashboard.java
package jan1;

public class Doctordashboard extends javax.swing.JFrame {

  /
    public Doctordashboard() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("WELCOME DOCTOR");

        jMenu1.setText("File");

        jMenuItem1.setText("viewtest");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Addtest");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("patients");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("add patient");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setText("update patient");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setText("jMenuItem6");
        jMenu1.add(jMenuItem6);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

                        

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new viewtest().setVisible(true);        :
    }                                          

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addpatient().setVisible(true);      
    }                                          

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addtest().setVisible(true);        
    }                                          

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewpatient().setVisible(true);        
    }                                          

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Updatepatient().setVisible(true);        
    }                                          

  
    public static void main(String args[]) {
    
       

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doctordashboard().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

Staffdashboard.java
package jan1;

public class Staffdashboard extends javax.swing.JFrame {

   
    public Staffdashboard() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("welcome staff");

        jMenu1.setText("File");

        jMenuItem1.setText("Add doctor");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Add staff");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Add patient");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("Add test");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setText("appointmemts");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setText("view doctor");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        jMenuItem7.setText("Update doctor");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem7);

        jMenuItem8.setText("BILL");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem8);

        jMenuItem9.setText("VIEW DOCTOR");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem9);

        jMenuItem10.setText("VIEW PATIENT");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem10);

        jMenuItem11.setText("VIEW STAFF");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem11);

        jMenuItem12.setText("UPDATE PATIENT");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem12);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

  
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Adddoctor().setVisible(true);        
    }                                          

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addstaff().setVisible(true);

    }                                          

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addpatient().setVisible(true);       
    }                                          

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Addtest().setVisible(true);        
    }                                          

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Appointment().setVisible(true);       
    }                                          

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewdoctor_1().setVisible(true);        
    }                                          

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Updatedoctor().setVisible(true);

    }                                          

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Bill().setVisible(true);       
    }                                          

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {                                           
new Viewdoctor_1().setVisible(true);        
    }                                          

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Viewpatient().setVisible(true);       
    }                                           

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Viewstaff().setVisible(true);

    }                                           

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {                                            
new Updatepatient().setVisible(true);        
    }                                           

   
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Staffdashboard().setVisible(true);
            }
        });
    }
                    
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatedoctor.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Updatedoctor extends javax.swing.JFrame {


    public Updatedoctor() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE DOCTOR");

        jLabel2.setText("USER NAME");

        jButton1.setText("search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("clear");

        jLabel3.setText("name");

        jLabel4.setText("age");

        jLabel5.setText("qualification");

        jLabel6.setText("address");

        jLabel7.setText("phone");

        jLabel8.setText("uname");

        jLabel9.setText("pwd");

        jButton3.setText("submit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

                         

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from doctor where uname=?");
            ps.setString(1,userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
              
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                qualification.setText(rs.getString(3));
                address.setText(rs.getString(4));
                phone.setText(rs.getString(5));
                adm.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
             
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }
              
        
                              
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
     uname.setText(" ") ;       
    }                                        

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
       try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update doctor set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, qualification.getText());
                ps.setString(4, address.getText());
               ps.setString(5,phone.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "DOCTOR Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    
    }                                        

    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatedoctor().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField address;
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                    
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatepatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Updatepatient extends javax.swing.JFrame {

   
    public Updatepatient() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
                         
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        disease = new javax.swing.JTextField();
        phone_number = new javax.swing.JTextField();
        guardian = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        pwd = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE PATIENT");

        jLabel2.setText("USER NAME");

        jLabel3.setText("NAME1");

        adm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admActionPerformed(evt);
            }
        });

        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setText("AGE1");

        jLabel6.setText("DISEASE");

        jLabel7.setText("PHONE_NUMBER");

        jLabel8.setText("GUARDOAN");

        jLabel9.setText("UNAME");

        jLabel10.setText("PWD");

        name.setText("\\\\");

            jButton2.setText("UPDATE");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            pwd.setText("jPasswordField1");

                                 

    private void admActionPerformed(java.awt.event.ActionEvent evt) {                                    
        
    }                                   

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from patient where uname=?");
            ps.setString(1,userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                disease.setText(rs.getString(3));
                guardian.setText(rs.getString(4));
                phone_number.setText(rs.getString(5));
                uname.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
                //not exists
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }        // TODO add your handling code here:
    }                                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
 try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update patient set name1 = ?, age1 = ?,disease = ?,phone_number = ?,guardian = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, disease.getText());
                ps.setString(4, phone_number.getText());
               ps.setString(5,guardian.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "patient Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }        
    }                                        

   
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatepatient().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JTextField disease;
    private javax.swing.JTextField guardian;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone_number;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JTextField uname;
                     
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Updatestaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lenovo
 */
public class Updatestaff extends javax.swing.JFrame {

  
    public Updatestaff() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adm = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        qualification = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        uname = new javax.swing.JTextField();
        pwd = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("UPDATE STAFF");

        jLabel2.setText("USER NAME");

        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");

        jLabel3.setText("NAME");

        jLabel4.setText("AGE");

        jLabel5.setText("QUALIFICATION");

        jLabel6.setText("ADDRESS");

        jLabel7.setText("PHONE");

        jLabel8.setText("UNAME");

        jLabel9.setText("PWD");

        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });

        pwd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pwdActionPerformed(evt);
            }
        });

        jButton3.setText("UPDATE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

                          

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {                                      
        // TODO add your handling code here:
    }                                     

    private void pwdActionPerformed(java.awt.event.ActionEvent evt) {                                    
        // TODO add your handling code here:
    }                                   

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
 String userName = adm.getText();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement
                ("select * from staff where uname=?");
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                //exist
                adm.setEditable(false);
               
                name.setText(rs.getString(1));
                age.setText(rs.getString(2));
                qualification.setText(rs.getString(3));
                address.setText(rs.getString(4));
                phone.setText(rs.getString(5));
                uname.setText(rs.getString(6));
                  pwd.setText(rs.getString(7));
             
            }
            else
            {
                //not exists
                JOptionPane.showMessageDialog(null, "Invalid User Name !!");
            }
        }catch(Exception e){
            System.out.println(e);
        }
              
        
                              
    }                                        

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
     try
             {
               Connection con = Connectiondb.getConnection();
                PreparedStatement ps = con.prepareStatement
                ("update staff set name = ?, age = ?,qualification = ?,address = ?,phone = ?,pwd = ? where uname=?");
               ps.setString(1, name.getText());
              ps.setString(2, age.getText());
              ps.setString(3, qualification.getText());
                ps.setString(4, address.getText());
               ps.setString(5,phone.getText());
             
            ps.setString(6, uname.getText());
            
            ps.setString(7,pwd.getText());
            int x = ps.executeUpdate();
            if(x&gt;0)
            {
                JOptionPane.showMessageDialog(null, "Staff Details updated");
                Updatestaff as = new Updatestaff();
                as.setVisible(true);
                this.dispose();
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }                                        

   
    public static void main(String args[]) {
    
   
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Updatestaff().setVisible(true);
            }
        });
    }

                       
    private javax.swing.JTextField address;
    private javax.swing.JTextField adm;
    private javax.swing.JTextField age;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JTextField pwd;
    private javax.swing.JTextField qualification;
    private javax.swing.JTextField uname;
                      
}
-------------------------------------------------------------------------------------------------------------
Viewdoctor_1.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;



public class Viewdoctor_1 extends javax.swing.JFrame {

    public Viewdoctor_1() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "qualification", "address", "phone", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
        });
        jScrollPane1.setViewportView(jTable1);

                           

    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from doctor");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String  age = rs.getString(2);
                String qualification = rs.getString(3);
                String address = rs.getString(4);
                String phone = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name, age, qualification, address, phone,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

  
    public static void main(String args[]) {
    

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewdoctor_1().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
Viewpatient.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;



public class Viewpatient extends javax.swing.JFrame {

    
    public Viewpatient() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // &lt;editor-fold defaultstate="collapsed" desc="Generated Code"&gt;                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "disease", "phone_number", "guardian", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

    
    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from patient");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name1 = rs.getString(1);
                String  age1 = rs.getString(2);
                String disease = rs.getString(3);
                String phone_number = rs.getString(4);
                String guardian = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name1, age1, disease, phone_number, guardian,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewpatient().setVisible(true);
            }
        });
    }

                        
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewstaff.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class Viewstaff extends javax.swing.JFrame {

    public Viewstaff() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "age", "qualification", "address", "phone", "uname", "pwd"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from doctor");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String  age = rs.getString(2);
                String qualification = rs.getString(3);
                String address = rs.getString(4);
                String phone = rs.getString(5);
                String uname = rs.getString(6);
                String pwd = rs.getString(7);
                Object ob[] = {name, age, qualification, address, phone,uname,pwd};
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Viewstaff().setVisible(true);
            }
        });
    }

                      
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                  
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
hmsproject.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class hmsproject extends javax.swing.JFrame {

    
    public hmsproject() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
                          
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        staffr = new javax.swing.JRadioButton();
        doctorr = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        namer = new javax.swing.JTextField();
        pwd = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("LOGIN FORM");

        jLabel2.setText("NAME ");

        jLabel3.setText("PASSWORD");

        buttonGroup1.add(staffr);
        staffr.setText("STAFF");

        buttonGroup1.add(doctorr);
        doctorr.setText("DOCTOR");

        jButton1.setText("LOGIN");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("CLEAR");

        jLabel4.setText("LOGIN AS");

                           

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
         
        try{
            Connection con=Connectiondb.getConnection();
            PreparedStatement ps=null;
            if(staffr.isSelected()){
                ps=con.prepareStatement("select * from staff where uname=? and pwd=?");
                ps.setString(1,namer.getText());
                 ps.setString(2,pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next()){
                      JOptionPane.showMessageDialog(null, "Welcome STAFF");
                    Staffdashboard sd = new Staffdashboard();
                    sd.setVisible(true);        //to open new frame ad
                    this.dispose();
                }
                else
                {
                    //invalid admin
                    JOptionPane.showMessageDialog(null, "Invalid Uname or Password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);        //to open new frame ad
                    this.dispose();             //to close current frame
                }
                    
                
            }
              else if(doctorr.isSelected())      //radio button selection
            {
                //teacher login
                ps = con.prepareStatement
                    ("select * from doctor where uname=? and pwd=?");
                ps.setString(1, namer.getText());
                ps.setString(2, pwd.getText());
                ResultSet rs=ps.executeQuery();
                if(rs.next())
                {   // valid teacher
                    JOptionPane.showMessageDialog(null,"welocome DOCTOR");
                    Doctordashboard td =new Doctordashboard();
                    td.setVisible(true);
                    this.dispose();
                    
                }
                else
                {  // Invalid teacher
                    JOptionPane.showMessageDialog(null,"Invalid username and password");
                    hmsproject hms = new hmsproject();
                    hms.setVisible(true);
                    this.dispose();
                    
                }
                
                
            }
   
        }  catch(Exception e)
        {
            System.out.println(e);
        }
        
 
    }                                        

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new hmsproject().setVisible(true);
            }
        });
    }

                       
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton doctorr;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField namer;
    private javax.swing.JPasswordField pwd;
    private javax.swing.JRadioButton staffr;
                  
}
-------------------------------------------------------------------------------------------------------------------------------------------------------------------Viewtest.java
package jan1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;


public class viewtest extends javax.swing.JFrame {

   
    public viewtest() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NAME", "FEES", "DESC", "DOCT"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

       
    private void formWindowActivated(java.awt.event.WindowEvent evt) {                                     
          DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            Connection con = Connectiondb.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from teacher");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                String name = rs.getString(1);
                String fees = rs.getString(2);
                String desc= rs.getString(3);
                String doct = rs.getString(4);
            
                
                Object ob[] = {name, fees, desc,doct };
                model.addRow(ob);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }                                    


    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewtest().setVisible(true);
            }
        });
    }
                     
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
                      
}
----------------------------------------------------------------------------------------------------------------------------------------------------------------
queries for creating tables
create database hms;// for creating database
use hms;
create table staff(
name varchar(100),
age varchar(100),
qualification varchar(100),
address varchar(100),
phone varchar(100),
uname varchar(100),
pwd varchar(100));

create table doctor(
name varchar(100),
age varchar(100),
qualification varchar(100),
address varchar(100),
phone varchar(10),
uname varchar(100),
pwd varchar(100));
  

create table patient(
name1 varchar(100),
age1 varchar(100),
disease varchar(100),
phone_number varchar(100),
guardian varchar(100),
uname varchar(100),
pwd varchar(100));

create table appointment(
name varchar(100),
dname varchar(100),
page varchar(100),
date varchar(100));

create table test(
name1 varchar(100),
fees varchar(100),
desc varchar(100),
doct varchar(100));


</pre><p>&nbsp;</p><p>In the above code, jan1 is the name of the package. We create all the classes under the same package so that we can easily inherit methods of different classes.</p><p>so we can say that<strong> jan1</strong> is the package and</p><ol><li>Adddoctor.java</li><li>Addpatient.java</li><li>Addstaff.java</li><li>Addtest.java</li><li>Appointment.java</li><li>Bill.java</li><li>Connection.java</li><li>Doctordashboard.java</li><li>Staffdashboard.java</li><li>Updatedoctor.java</li><li>Updatepatient.java</li><li>Updatestaff.java</li><li>Viewdoctor_1.java</li><li>Viewpatient.java</li><li>Viewstaff.java</li><li>hmsproject.java</li><li>Viewtest.java</li></ol><p>are the classes inside package<strong> jan1.</strong></p><h3 style="text-align: center;">For Connectivity</h3><p>We use Class.forName(“com.mysql.jdbc.Driver”) for loading Mysql driver to establish Connection.</p><p>Connection con; con=DriverManager.getConnection(“JDBC<strong>:mysql://localhost:3306/hms”,”root”,”98188</strong>“);</p><p>A connection is an interface that we use for the connection. In the above bold link localhost is the name of the server,hms is the name of the database, the root is the id of Mysql and 98188 is the password of Mysql.</p><p>This Connection.java is further inherited by each and every class because every class is either fetching data from the database or entering data in the database. And in each class</p><p>PreparedStatement stmt=con.createStatement();</p><p>is used. We use the prepareStatement() method of Connection interface to prepare the SQL statements.</p><p>We use the object of the Statement interface for executing queries. executeQuery() method is used for executing database queries. And the object of ResultSet is either used to fetch or to store records in the database. These statements discussed below are used for connectivity.</p><ol><li>Class.forName (“com.mysql.jdbc.Driver”);</li><li>Connection con=null;</li><li>con=DriverManager.getConnection(“jdbc:mysql://localhost:3306/hms”,”root”,”98188″);</li><li>Statement ps=con.createStatement(” sql query “)</li><li>ResultaSet rs=ps.executeQuery(” sql query “)</li><li>rs.setString() or rs.getString()</li></ol><p>We can enter data to the database using ps.setString.</p><p>PrepareStatement is the Interface and prepareStatement() is the name of the method. we can differentiate both on the basis of the first letter of their spelling ie. p. In case of Interface we use capital p (P) but in case of the method we use small p (p).</p><div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180" data-fuse-code="fuse-slot-22688779180-3" data-fuse-slot="fuse-slot-22688779180-3" data-fuse-processed-at="6074"><div id="fuse-slot-22688779180-3" class="fuse-slot"></div></div></div><p>And we can fetch data from the database using ps.getString.</p><p>And At last, we close the connection using con.close().</p><p>For generating the connection, libraries and jar files are required.</p><p>Before using these Statements described above, package java.sql must be imported.</p><h3 style="text-align: center;">Front end</h3><p>Further to make it attractive we use a graphical user interface. For generating front end we can use</p><ol><li>label</li><li>text area</li><li>button</li><li>button group</li><li>password field</li><li>radio buttons</li></ol><p>These labels, swings, buttons, etc are part of swings. For using swings, we usually import swing package. Syntax ( import javax.swing.*)</p><p>JOptionPane.showMessageDialog(null,”ANY MESSAGE”)&nbsp; displays dialogue box containing message on the screen.</p><ol><li>private void jButton2ActionPerformed(java.awt.event.ActionEvent evt)</li></ol><p>2. private void jButton3ActionPerformed(java.awt.event.ActionEvent evt)</p><p>We use these methods to describe the working of the project on clicking the button.</p><p>jButton2,jButton3 are the names of the buttons we can change their names if we want.</p><p>jButton2ActionPerformed(java.awt.event.ActionEvent evt) is the complete name of method.</p><p>We use private access specifier as private specifiers specify that we can run the method only within the same class. Any other class of the same package will not be able to access the methods.</p><h4 style="text-align: center;">Exceptions</h4><p>We use the Try-catch block in case of java database connectivity for the normal flow of code ie. flow of code is not affected by any Exception. Generally, code is enclosed in the try block and catch block is used to catch the exception thrown by the try block. We can also use finally block. Finally block is always executed by the compiler.</p><p>&nbsp;</p><h3 style="text-align: center;">To run the entire hospital management project in Java follow these steps</h3><p>To run the project First of all run hms.java</p><p>The form that we will receive by running hms.java class.</p><p><img class="aligncenter size-full wp-image-30357" src="./HospitalManagement_files/hosiptal-managemnet-system-in-Java.png" alt="hosiptal managemnet system in Java" width="603" height="633" srcset="https://cdn.codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java.png 603w, https://cdn.codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java-286x300.png 286w" sizes="(max-width: 603px) 100vw, 603px"></p><p>we can either log in as a doctor or as staff by entering a valid username and password.</p><p>If we log in as doctor we will receive doctor dashboard</p><p><img loading="lazy" class="aligncenter size-full wp-image-30358" src="./HospitalManagement_files/hosiptal-managemnet-system-in-Java-doctor-dashboard.png" alt="hosiptal managemnet system in Java doctor dashboard" width="616" height="548" srcset="https://cdn.codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java-doctor-dashboard.png 616w, https://cdn.codespeedy.com/wp-content/uploads/2020/01/hosiptal-managemnet-system-in-Java-doctor-dashboard-300x267.png 300w" sizes="(max-width: 616px) 100vw, 616px"></p><p>If we will log in as staff we will receive staff dashboard</p><p><a href="https://cdn.codespeedy.com/wp-content/uploads/2020/01/staffdashboard.docx">staffdashboard.docx</a></p><p>Further, we can run any file from the dashboard.</p><p>some of the forms from the project are:</p><p><a href="https://cdn.codespeedy.com/wp-content/uploads/2020/01/out.docx">output.docx</a></p><p>Also read:</p><ul><li><a href="https://www.codespeedy.com/creating-a-user-defined-kafka-producer-application-in-java/">Creating a User Defined Kafka Producer Application in Java</a></li></ul><p></p>  <script type="text/javascript">const post_content = document.getElementById('post-content');
  	const paragraph_for_ad = post_content.getElementsByTagName("p");
  	// console.log("FRK");
  	//console.log("frk tag"+paragraph_for_ad.length);


    if (window.innerWidth < 900){

  	    if (paragraph_for_ad.length > 5) {

    	   let adparagraph = paragraph_for_ad[2];
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180"></div></div>');
  	    }
  	    if (paragraph_for_ad.length > 15) {

    	   let adparagraph = paragraph_for_ad[10];
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180"></div></div>');
  	    }

  	    if (paragraph_for_ad.length > 30) {

    	   let adparagraph = paragraph_for_ad[25];
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:302px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22688779180"></div></div>');
  	    }




    } else if(window.innerWidth > 1360) {

  	    if (paragraph_for_ad.length > 15) {

    	   let adparagraph = paragraph_for_ad[10];
    	   // 71161633/article_incontent_1/article_incontent_1
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:92px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22689137525"></div></div>');
  	    }


  	    if (paragraph_for_ad.length > 22) {

    	   let adparagraph = paragraph_for_ad[18];
    	   // 71161633/article_incontent_2/article_incontent_2 
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:92px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22689137522"></div></div>');
  	    }


  	    if (paragraph_for_ad.length > 30) {

    	   let adparagraph = paragraph_for_ad[29];
    	   // 71161633/article_incontent_1/article_incontent_1
           adparagraph.insertAdjacentHTML('afterEnd', '<div style="height:92px;margin-top:6px;margin-bottom:8px;"><div data-fuse="22689137525"></div></div>');
  	    }


    }</script> <div id="respond" class="comment-respond"><h3 id="reply-title" class="comment-reply-title">Leave a Reply <small><a rel="nofollow" id="cancel-comment-reply-link" href="https://www.codespeedy.com/hospital-management-system-using-core-java/#respond" style="display:none;">Cancel reply</a></small></h3><form action="https://www.codespeedy.com/wp-comments-post.php" method="post" id="commentform" class="comment-form"><p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> <span class="required-field-message" aria-hidden="true">Required fields are marked <span class="required" aria-hidden="true">*</span></span></p><p class="comment-form-comment"><label for="comment">Comment <span class="required" aria-hidden="true">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required"></textarea></p><p class="comment-form-author"><label for="author">Name <span class="required" aria-hidden="true">*</span></label> <input id="author" name="author" type="text" value="" size="30" maxlength="245" required="required"></p><p class="comment-form-email"><label for="email">Email <span class="required" aria-hidden="true">*</span></label> <input id="email" name="email" type="text" value="" size="30" maxlength="100" aria-describedby="email-notes" required="required"></p><p class="form-submit"></p><div id="g-recaptcha-0" class="g-recaptcha" data-sitekey="6LdHbTkdAAAAAODFstiotyNLZWXkGA9aRzZuOhYr" data-theme="light" data-widget-id="0"><div style="width: 304px; height: 78px;"><div><iframe title="reCAPTCHA" src="./HospitalManagement_files/anchor.html" width="304" height="78" role="presentation" name="a-pdp2d0hxjnle" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;" src="./HospitalManagement_files/saved_resource(1).html"></iframe></div><noscript>Please enable JavaScript to submit this form.<br></noscript><input name="submit" type="submit" id="submit" class="submit" value="Post Comment"> <input type="hidden" name="comment_post_ID" value="29541" id="comment_post_ID"> <input type="hidden" name="comment_parent" id="comment_parent" value="0"><p></p></form></div></div><div class="post-nav-links"><hr><div class="prv-pst">« <a href="https://www.codespeedy.com/comma-separated-string-to-array-in-cpp/" rel="prev">Comma separated string to Array in C++</a></div><div class="nxt-pst"><a href="https://www.codespeedy.com/merge-two-dictionaries-in-python-update-double-star/" rel="next">Merge two dictionaries in Python using update and double star</a> »</div></div></div><div class="col-sm-3"><form class="search-sidebar" action="https://www.codespeedy.com/" method="get"> <input type="text" name="s" id="search" value=""> <button type="submit" value="Search">Search</button></form><div id="sbid" class="sidebar"><div id="recent-posts-3" class="widget widget_recent_entries"><div class="widsidebar"><p class="widgettitle">Latest Articles</p><ul><li> <a href="https://www.codespeedy.com/find-index-of-maximum-and-minimum-element-in-vector-in-c/">How to find index of maximum and minimum element in vector in C++</a></li><li> <a href="https://www.codespeedy.com/dictionaries-in-swift/">Dictionaries in Swift</a></li><li> <a href="https://www.codespeedy.com/create-a-dictionary-from-an-array-in-swift/">Create a dictionary from an array in Swift</a></li><li> <a href="https://www.codespeedy.com/how-to-add-a-character-to-a-specific-position-in-a-string-in-php/">How to add a character to a specific position in a string in PHP</a></li><li> <a href="https://www.codespeedy.com/how-to-set-all-elements-of-an-array-to-0-in-cpp/">How to set all elements of an array to 0 in C++</a></li></ul></div></div></div><div style="height: 281px;"><div data-fuse="22689137501" data-fuse-code="fuse-slot-22689137501-1" data-fuse-slot="fuse-slot-22689137501-1" data-fuse-processed-at="6074"><div id="fuse-slot-22689137501-1" class="fuse-slot"></div></div></div><div class="related-post"></div><div id="vi-sticky-ad"></div> <script>if (window.innerWidth > 900){
                var adElemSticky = document.getElementById('vi-sticky-ad');
                var adlElemSticky = document.getElementById('l-sticky-ad');
                window.onscroll = function() {


                        var adElem = document.getElementById('vi-ad');
                        var rect = adElemSticky.getBoundingClientRect();
                        adElemSticky.style.width = rect.width + 'px';
                        adElemSticky.style.height = rect.height + 'px';
                        if (rect.top <= 0){
                                adElem.style.position = 'fixed';
                                adElem.style.top = '2px';
                                adElem.style.zIndex = '2147483647';
                                adElem.style.width = rect.width + 'px';
                                adElem.style.height = rect.height + 'px';
                        } else {
                                adElem.style.position = '';
                                adElem.style.top = '';
                                adElem.style.zIndex = '';
                                adElem.style.width = '';
                                adElem.style.height = '';
                        }





                        var adlElem = document.getElementById('l-vi-ad');
                        var lrect = adlElemSticky.getBoundingClientRect();
                        adlElemSticky.style.width = lrect.width + 'px';
                        adlElemSticky.style.height = lrect.height + 'px';
                        if (lrect.top <= 0){
                                adlElem.style.position = 'fixed';
                                adlElem.style.top = '2px';
                                adlElem.style.zIndex = '2147483647';
                                adlElem.style.width = lrect.width + 'px';
                                adlElem.style.height = lrect.height + 'px';
                        } else {
                                adlElem.style.position = '';
                                adlElem.style.top = '';
                                adlElem.style.zIndex = '';
                                adlElem.style.width = '';
                                adlElem.style.height = '';
                        }





                };
        }


     (function() {


      var adElemSticky = document.getElementById('vi-sticky-ad');
     var width = window.innerWidth;
     if( width <= 1200 ){
        adElemSticky.innerHTML = '';
     }



      var adlElemSticky = document.getElementById('l-sticky-ad');
     var width = window.innerWidth;
     if( width <= 1200 ){
        adlElemSticky.innerHTML = '';
     }

     

     }())</script> </div></div><footer><div class="container"><div class="col-sm-4"></div><div class="col-sm-4"><div id="custom_html-14" class="widget_text footer-widget"><div class="textwidget custom-html-widget"><ul><li><a href="https://www.codespeedy.com/category/python/">Python</a> | <a href="https://www.codespeedy.com/category/java/">Java</a> | <a href="https://www.codespeedy.com/category/cpp-programming/">C++</a> | <a href="https://www.codespeedy.com/category/machine-learning/">Machine Learning</a> | <a href="https://www.codespeedy.com/category/javascript/">JavaScript</a></li></ul><ul><li><a href="https://www.codespeedy.com/privacy-policy/">Privacy policy</a> | <a href="https://www.codespeedy.com/contact-us/">Contact</a> | <a href="https://www.codespeedy.com/about-us/">About</a></li></ul></div></div></div><div class="col-sm-4"><div class="footer-widget"><p>By continuing to visit our website, you agree to the use of cookies as described in our <a style="color:#87cded;" target="_blank" href="https://www.codespeedy.com/cookie-policy/">Cookie Policy</a></p></div></div></div></footer>  <script type="text/javascript">var recaptcha_widgets={};
		function wp_recaptchaLoadCallback(){
			try {
				grecaptcha;
			} catch(err){
				return;
			}
			var e = document.querySelectorAll ? document.querySelectorAll('.g-recaptcha:not(.wpcf7-form-control)') : document.getElementsByClassName('g-recaptcha'),
				form_submits;

			for (var i=0;i<e.length;i++) {
				(function(el){
					var wid;
					// check if captcha element is unrendered
					if ( ! el.childNodes.length) {
						wid = grecaptcha.render(el,{
							'sitekey':'6LdHbTkdAAAAAODFstiotyNLZWXkGA9aRzZuOhYr',
							'theme':el.getAttribute('data-theme') || 'light'
						});
						el.setAttribute('data-widget-id',wid);
					} else {
						wid = el.getAttribute('data-widget-id');
						grecaptcha.reset(wid);
					}
				})(e[i]);
			}
		}

		// if jquery present re-render jquery/ajax loaded captcha elements
		if ( typeof jQuery !== 'undefined' )
			jQuery(document).ajaxComplete( function(evt,xhr,set){
				if( xhr.responseText && xhr.responseText.indexOf('6LdHbTkdAAAAAODFstiotyNLZWXkGA9aRzZuOhYr') !== -1)
					wp_recaptchaLoadCallback();
			} );</script><script src="./HospitalManagement_files/api.js.download" async="" defer=""></script>  <script type="text/javascript" src="./HospitalManagement_files/comment-reply.min.js.download" id="comment-reply-js"></script> <script type="text/javascript" id="edd-ajax-js-extra">var edd_scripts = {"ajaxurl":"https:\/\/www.codespeedy.com\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"paypal","redirect_to_checkout":"1","checkout_page":"https:\/\/www.codespeedy.com\/checkout\/?nocache=true","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};</script> <script type="text/javascript" src="./HospitalManagement_files/edd-ajax.min.js.download" id="edd-ajax-js"></script> <script type="text/javascript" id="rocket-browser-checker-js-after">"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();</script> <script type="text/javascript" id="rocket-preload-links-js-extra">var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/checkout\/|\/(index\\.php\/)?wp\\-json(\/.*|$)|\/wp-admin\/|\/logout\/|\/wp-login.php|\/go\/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm","siteUrl":"https:\/\/www.codespeedy.com","onHoverDelay":"100","rateThrottle":"3"};</script> <script type="text/javascript" id="rocket-preload-links-js-after">(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());</script> <script type="text/javascript" src="./HospitalManagement_files/enlighterjs.min.js.download" id="enlighterjs-js"></script> <script type="text/javascript" id="enlighterjs-js-after">!function(e,n){if("undefined"!=typeof EnlighterJS){var o={"selectors":{"block":"pre.EnlighterJSRAW","inline":"code.EnlighterJSRAW"},"options":{"indent":2,"ampersandCleanup":true,"linehover":true,"rawcodeDbclick":false,"textOverflow":"scroll","linenumbers":true,"theme":"atomic","language":"generic","retainCssClasses":false,"collapse":false,"toolbarOuter":"","toolbarTop":"{BTN_RAW}{BTN_COPY}{BTN_WINDOW}{BTN_WEBSITE}","toolbarBottom":""}};(e.EnlighterJSINIT=function(){EnlighterJS.init(o.selectors.block,o.selectors.inline,o.options)})()}else{(n&&(n.error||n.log)||function(){})("Error: EnlighterJS resources not loaded yet!")}}(window,console);</script> <script>window.lazyLoadOptions={elements_selector:"iframe[data-lazy-src]",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded")){if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}};window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0;var rocketlazy_count=0;mutations.forEach(function(mutation){for(var i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){continue}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){continue}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script><script data-no-minify="1" async="" src="./HospitalManagement_files/lazyload.min.js.download"></script><script>function lazyLoadThumb(e){var t='<img src="https://i.ytimg.com/vi/ID/hqdefault.jpg" alt="" width="480" height="360">',a='<button class="play" aria-label="play Youtube video"></button>';return t.replace("ID",e)+a}function lazyLoadYoutubeIframe(){var e=document.createElement("iframe"),t="ID?autoplay=1";t+=0===this.parentNode.dataset.query.length?'':'&'+this.parentNode.dataset.query;e.setAttribute("src",t.replace("ID",this.parentNode.dataset.src)),e.setAttribute("frameborder","0"),e.setAttribute("allowfullscreen","1"),e.setAttribute("allow", "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"),this.parentNode.parentNode.replaceChild(e,this.parentNode)}document.addEventListener("DOMContentLoaded",function(){var e,t,p,a=document.getElementsByClassName("rll-youtube-player");for(t=0;t<a.length;t++)e=document.createElement("div"),e.setAttribute("data-id",a[t].dataset.id),e.setAttribute("data-query", a[t].dataset.query),e.setAttribute("data-src", a[t].dataset.src),e.innerHTML=lazyLoadThumb(a[t].dataset.id),a[t].appendChild(e),p=e.querySelector('.play'),p.onclick=lazyLoadYoutubeIframe});</script>    <script async="" src="./HospitalManagement_files/js"></script> <script>window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-72126234-3');</script> 
<!-- This website is like a Rocket, isn't it? Performance optimized by WP Rocket. Learn more: https://wp-rocket.me - Debug: cached@1651021333 --><iframe name="__tcfapiLocator" style="display: none;" src="./HospitalManagement_files/saved_resource(2).html"></iframe><div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;"><div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div><div class="g-recaptcha-bubble-arrow" style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div><div class="g-recaptcha-bubble-arrow" style="border: 10px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000;"></div><div style="z-index: 2000000000; position: relative;"><iframe title="recaptcha challenge expires in two minutes" src="./HospitalManagement_files/bframe.html" name="c-pdp2d0hxjnle" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 100%; height: 100%;"></iframe></div></div><style id="publift-widget-22688779183-styles">
.publift-widget-22688779183-container {
  z-index: 2147483645;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 50px;
  transition: transform .3s linear, height .3s linear;
  overflow: hidden;
  visibility: hidden;
  left: 0;
}
.publift-widget-22688779183-container-background {
  background-color: #EFEFEF;
  opacity: 0;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: -1;
}

.publift-widget-22688779183-button {
  width: 40px;
  margin-left: 2px;
  height: 20px;
  background-color: #EFEFEF;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  position: absolute;
  display: none;
  transition: top .3s linear;
  border-radius: 0 0 2px 2px; top: 0px;
}
.publift-widget-22688779183-button :first-child, .publift-widget-22688779183-button :last-child  {
  background-color: #313131;
  width: 13px;
  height: 3px;
  border-radius: 2px;
}
.publift-widget-22688779183-button :first-child {
  transform: rotate(30deg) translateX(2px);
}
.publift-widget-22688779183-button :last-child {
  transform: rotate(-30deg) translateX(-2px);
}
.publift-widget-22688779183 {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: transform .3s linear, height .3s linear;
  border-top: 0px solid #EFEFEF;
}
.publift-widget-22688779183-container.closed {
  height: 0px;
}
.publift-widget-22688779183-container.closed .publift-widget-22688779183-button {
  display: none;
}
.publift-widget-22688779183-container.closed .publift-widget-22688779183-button :first-child {
  transform: rotate(-30deg) translateX(2px);
}
.publift-widget-22688779183-container.closed .publift-widget-22688779183-button :last-child {
  transform: rotate(30deg) translateX(-2px);
}

</style><div class="publift-widget-22688779183-container closed" style="display: block; height: 50px;">
<div class="publift-widget-22688779183-container-background">
</div>
  <div class="publift-widget-22688779183-button">
    <div></div>
    <div></div>
  </div>
  <div class="publift-widget-22688779183" style="height: 50px;">
  <div id="fuse-injected-22688779183-1" data-fuse="22688779183" data-fuse-injected-at="1651037149740" class="fuse-slot-sticky" data-fuse-code="fuse-slot-22688779183-1" data-fuse-slot="fuse-slot-22688779183-1" data-fuse-processed-at="6068"><div id="fuse-slot-22688779183-1" class="fuse-slot"></div></div></div>
</div></body><iframe sandbox="allow-scripts allow-same-origin" id="211ffba681255543" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/showad.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="2121c6c8f2886575" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/pd.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="21370e973267fcbe" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/usync.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="2145d7cfe63f2686" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/ixmatch.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="215e5db33909d501" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/sync.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="2166aca8da4da387" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/connectmyusers.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="2175dbf75a55d18" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/async_usersync.html">
    </iframe><iframe sandbox="allow-scripts allow-same-origin" id="21827267620a72b1" frameborder="0" allowtransparency="true" marginheight="0" marginwidth="0" width="0" hspace="0" vspace="0" height="0" style="height:0px;width:0px;display:none;" scrolling="no" src="./HospitalManagement_files/saved_resource(3).html">
    </iframe></html>