package com.spring.jdbc.employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.jdbc.employee.dao.EmployeeDao;
import com.spring.jdbc.employee.entities.Employee;



public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbc/employee/applicationContext.xml");
		EmployeeDao empdao = context.getBean("EmployeeDao", EmployeeDao.class);
		Employee e = new Employee();
		s.setId(100);
		s.setName("garima");
		// insert
		int r = empdao.insert(s);
	  System.out.println(r + "Employee insert Successfully ");

		// update
		// int r=stdao.updatedetails(s);
		// System.out.println(r + "Student update Successfully ");
		
		// delete
		// int r = stdao.delete(105);
		// System.out.println(r + "Student delete Successfully ");

		// showing data from database
		//Employee employee = empdao.getEmployee(100);
		//System.out.println(employee);

	}

}
