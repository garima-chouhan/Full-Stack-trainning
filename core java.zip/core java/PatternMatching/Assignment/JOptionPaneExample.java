import javax.swing.*;  
public class JOptionPaneExample {  
  
JOptionPaneExample(){  
 JFrame f=new JFrame();  
    JOptionPane.showMessageDialog(f,"Hello, Welcome to Yash Technologies.");  
}  
public static void main(String[] args) {  
    new JOptionPaneExample();  
}  
}  