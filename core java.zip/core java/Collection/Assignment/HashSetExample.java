import java.util.HashSet;
import java.util.Iterator;  
class HashSetExample{  
 public static void main(String args[]){  
    
    HashSet<String> set=new HashSet<String>();  
           set.add("1");    
           set.add("2");    
           set.add("3");   
           set.add("4");  
           set.add("1"); 
           set.add("3");		   
           Iterator<String> i=set.iterator();  
           while(i.hasNext())  
           {  
           System.out.println(i.next());  
           }  
 }  
}