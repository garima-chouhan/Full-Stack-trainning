class ThreadDemo extends Thread{
public void run()
{
System.out.println("i am extends thread");
}
public static void main(String args[])
{
 ThreadDemo t=new ThreadDemo();
 t.start();

}


}