import java.util.HashSet;
import java.util.Iterator;

public class AssignmentHashSet {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		
		set.add("Anil");
		set.add("Ajay");
		set.add("Rahul");
		set.add("Richa");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}