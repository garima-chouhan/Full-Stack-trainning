import java.io.IOException;
class Add
{
void test() throws IOException
{
throw new IOException("Hello Device");

}
}
class ThrowsAdd
{
public static void main(String args[])
{
try
{
Add a=new Add();
a.test();

}

catch(Exception e)
{
System.out.println("exception handled");
}     
  
 System.out.println("normal flow..."); 


}

}