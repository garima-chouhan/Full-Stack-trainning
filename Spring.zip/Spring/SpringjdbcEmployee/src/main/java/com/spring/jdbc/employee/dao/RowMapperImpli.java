package com.spring.jdbc.employee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.tree.RowMapper;
import javax.swing.tree.TreePath;

import com.spring.jdbc.employee.entities.Employee;



public class RowMapperImpli implements RowMapper {
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee employee = new Employee();
		Employee.setEmpid(rs.getInt(1));
		Employee.setEmpname(rs.getString(2));
		Employee.setContactno(rs.getInt(3));
		Employee.setSalary(rs.getInt(4));
		//student.setCity(rs.getString(3));
		return employee;
	}

	public int[] getRowsForPaths(TreePath[] path) {
		// TODO Auto-generated method stub
		return null;
	}

}
