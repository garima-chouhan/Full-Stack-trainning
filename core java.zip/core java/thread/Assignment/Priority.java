public class Priority extends Thread
{

public void run()
{
System.out.println("i am in method");
System.out.println(Thread.currentThread().getPriority());

}

public static void main(String args[])
{
System.out.println(Thread.currentThread().getPriority());
Thread.currentThread().setPriority(MIN_PRIORITY);
System.out.println(Thread.currentThread().getPriority());//1
System.out.println(Thread.currentThread().getPriority());//1
Priority p=new Priority();
p.setPriority(8);//illegalArgumentException
p.start();
}
}