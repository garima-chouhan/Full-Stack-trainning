class Demo4
{
void y1(Demo4 d)
{
System.out.println("y1 Method");

}
void y2()
{
 y1(this);

}
public static void main(String args[])
{
Demo4 d= new Demo4();
d.y2();
}
}