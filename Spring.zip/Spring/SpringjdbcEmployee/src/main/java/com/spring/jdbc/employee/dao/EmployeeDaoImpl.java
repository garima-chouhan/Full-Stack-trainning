package com.spring.jdbc.employee.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.spring.jdbc.dao.RowMapperImpli;
import com.spring.jdbc.entites.Employee;

public class EmployeeDaoImpl {
	private JdbcTemplate jdbctemp;

	public int insert(Employee emp) {

		String q = "insert into employee(empid,empname,contactno,salary) values(?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getId(), emp.getName());
		return msg;
	}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	public int updatedetails(Employee emp) {
		// update details of Employee
		String q = "update student set empname=? where empid=?";
		int msg = this.jdbctemp.update(q, emp.getEmpName(), emp.getEmpId());

		return msg;
	}

	public int delete(int EmployeeId) {
		// delete operation
		String query = "delete from Employee where empid=?";
		int r = this.jdbctemp.update(query, EmployeeId);
		return r;
	}

	public Employee getEmployee(int EmployeeId) {
		// select single Employee data
		String query = "select * from employee where empid=?";
		RowMapper<Student> rowMapper = new RowMapperImpli();
		Employee employee = this.jdbctemp.queryForObject(query, rowMapper, employeeId);

		return employee;
	}

}

