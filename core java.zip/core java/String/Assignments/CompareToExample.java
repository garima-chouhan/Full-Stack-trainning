class CompareToExample{
  public static void main(String args[])
{
 String s1="Garima";
 String s2="Garima";
String s3="Hello";
String s4="gourav";
 System.out.println(s1.compareTo(s2));
  System.out.println(s1.compareTo(s3));
 System.out.println(s1.compareTo(s4));
 

}

}