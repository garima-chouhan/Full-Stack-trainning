public class IsAlive extends Thread
{

public void run()
{
	
System.out.println("run:"+Thread.currentThread().getName());
}
public static void main(String args[])
{
System.out.println(Thread.currentThread().getName());
 IsAlive a=new IsAlive();
 a.setName("hey");
a.start();
System.out.println(a.isAlive());
System.out.println(Thread.currentThread().isAlive());

IsAlive a1=new IsAlive();
a1.setName("hello");
a1.start();

IsAlive a2=new IsAlive();
a2.setName("hii");
a2.start();

}
}