import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
class FileTryCatch
{
public static void main(String args[]) throws IOException
{
	 FileInputStream fi=null;
	 FileOutputStream fo=null;
	try 
 {
  fi=new FileInputStream("d:/yash/abc.txt");
  fo=new FileOutputStream("d:/yash/xyz.txt");
 int c;

  while((c=fi.read())!=-1)
  {
	  fo.write(c);
   System.out.println((char)c);
  }
 
 }
 finally
 {
	 if(fi!=null)
	 {
		 fi.close();
	 }
	 if(fo!=null)
	 {
         fo.close();
	 }
 }

}


}