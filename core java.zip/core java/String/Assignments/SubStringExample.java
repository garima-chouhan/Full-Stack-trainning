class SubStringExample{
   public static void main(String args[])
{
String s="welcome ";
System.out.println(s.substring(3,7));


}

}