import java.sql.*;
import java.util.*;
class PreparedStatementExample{
public static void main(String args[])throws Exception{
	try
	{
class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/emp_record";
String user="root";
String pass="root";
Connection con = DriverManager.getConnection(url,user,pass);
String sqlquery = "insert into employee values(? ? ? ?)";
preparedStatement pst = con.prepareStatement(sqlquery);
Scanner sc = new Scanner(System.in);


System.out.println("Enter employee number: ");
int eno = sc.nextInt();
System.out.println("Enter employee name: ");
String ename = sc.next();
System.out.println("Enter employee salary: ");
double esal = sc.nextDouble();
System.out.println("Enter employee address: ");
String eaadr = sc.next();;

pst.setInt(1,eno);
pst.setString(2,ename);
pst.setDouble(3, esal);
pst.setString(4, eddr);
pst.excecuteUpdate();

System.out.println("Record inserted succesfully ");
System.out.println("Do you want to insert more records[yes/no]");
con.close();
}

catch(Exception e)
{
	e.printStackTrace();
}
}
}
