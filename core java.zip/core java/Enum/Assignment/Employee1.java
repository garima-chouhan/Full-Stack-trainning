import java.io.Serializable;
import java.io.File;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

 class Employee implements Serializable {
	private String name;
	private String department;
	private String designation;
	private double salary;
	
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getDepartment() 
	{
		return department;
	}
	public void setDepartment(String department)
	{
		this.department = department;
	}
	public String getDesignation()
	{
		return designation;
	}
	public void setDesignation(String designation) 
	{
		this.designation = designation;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	
	
}
	class Employee1
	{    	
		public static void main(String args[]) throws Exception
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter name");
			String name = sc.nextLine();
			System.out.println("Enter department");
			String department = sc.nextLine();
			System.out.println("Enter destination");
			String designation = sc.nextLine();
			System.out.println("Enter salary");
			double salary = sc.nextDouble();
			
		     Employee e = new Employee();
			 System.out.println(e);
			File f=new File("d:/yash/yash.txt");
            
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            oos.writeObject(e);
            oos.flush();
            oos.close();
			System.out.println("name is: " + name);
			System.out.println("salary is: " + salary);
			System.out.println("department is: " + department);
			System.out.println("designation is: " + designation);
        }
		}
	


	
	  