public class DaemonThread extends Thread
{
	public void run()
	{
   if(Thread.currentThread().isDaemon())
   {
   
    System.out.println("DaemonThread");
   }
   else
   {
   System.out.println("non-DaemonThread");
   }

	}

public static void main(String args[])
{
	//Thread.currentThread().setDaemon();//we cannot create main thread
   System.out.println("main method");
  DaemonThread dt=new DaemonThread();
  dt.setDaemon(true);
  dt.start();

}
}