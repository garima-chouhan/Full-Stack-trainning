import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.SequenceInputStream; 
 class SequenceInputStreamExample
{    
 public static void main(String args[]) throws Exception 
 {    
  try
  {    
    FileInputStream fin1=new FileInputStream("D:/yash/xyz.txt");
     FileInputStream fin2=new FileInputStream("D:/yash/abc.txt");    
    SequenceInputStream sin=new SequenceInputStream(fin1,fin2);    
    int i;    
    while((i=sin.read())!=-1){    
     System.out.print((char)i);    
    }    
    sin.close();    
    fin1.close();
    fin2.close();    
  }
  catch(Exception e)
  {
  System.out.println(e);
  }    
 }    
}  