class SortAscArray{
public static void main(String args[])
{
 int[] a= new int[]{1,4,7,8,9,6,5};
 int temp=0;
   for(int i=0;i<a.length;i++)
{
     for(int j=0;j<a.length;j++)
{
     if(a[i]>a[j])
   {
     temp=a[i];
     a[i]=a[j];
     a[j]=temp;

}


}
}

System.out.println();

for(int i=0;i<a.length;i++)
{
 System.out.println(a[i]+"");
}
}
}
